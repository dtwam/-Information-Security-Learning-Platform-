
import React from 'react';
import { motion } from 'framer-motion';
import { Book, Shield, Wifi, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import './Courses.css';

/**
 * بيانات المواد الدراسية
 */
const courses = [
  {
    id: 'security-basics',
    title: 'أساسيات أمن المعلومات',
    icon: <Shield size={48} />,
    description: 'المفاهيم الأساسية في أمن المعلومات والأمن السيبراني',
    unitsCount: 0,
    color: '#3b82f6',
    status: 'coming-soon',
    path: '/course/security-basics'
  },
  {
    id: 'security-software',
    title: 'برمجيات وتطبيقات أمن المعلومات',
    icon: <Book size={48} />,
    description: 'اختبار اختراق الويب والتطبيقات الأمنية - Kali Linux',
    unitsCount: 7,
    color: '#8b5cf6',
    status: 'active',
    progress: 0,
    path: '/dashboard'
  },
  {
    id: 'wireless-security',
    title: 'أمن الشبكات اللاسلكية',
    icon: <Wifi size={48} />,
    description: 'حماية الشبكات اللاسلكية واختبار اختراقها',
    unitsCount: 0,
    color: '#10b981',
    status: 'coming-soon',
    path: '/course/wireless-security'
  }
];

/**
 * مكون صفحة المواد
 */
const Courses = () => {
  const navigate = useNavigate();

  const handleCourseSelect = (course) => {
    if (course.status === 'active') {
      navigate(course.path);
    }
  };

  return (
    <div className="courses-page">
      {/* ✅ الهيدر */}
      <header className="courses-header">
        <div className="header-content">
          <img 
            src="/logo.png" 
            alt="شعار جامعة القدس المفتوحة" 
            className="header-logo"
            loading="lazy"
          />
          <div className="header-text">
            <h1>جامعة القدس المفتوحة</h1>
            <p>تخصص أمن المعلومات</p>
          </div>
        </div>
      </header>

      {/* ✅ المحتوى الرئيسي */}
      <main className="courses-main">
        <motion.div 
          className="welcome-section"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2>اختر المادة الدراسية</h2>
          <p className="subtitle">المنصة التعليمية المتكاملة لدراسة أمن المعلومات</p>
        </motion.div>

        {/* ✅ شبكة المواد */}
        <div className="courses-grid">
          {courses.map((course, index) => (
            <motion.div
              key={course.id}
              className={`course-card ${course.status === 'active' ? 'course-card--active' : ''} ${course.status === 'coming-soon' ? 'course-card--soon' : ''}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
              whileHover={course.status === 'active' ? { y: -8, scale: 1.02 } : {}}
              whileTap={course.status === 'active' ? { scale: 0.98 } : {}}
              onClick={() => handleCourseSelect(course)}
              style={{ '--course-color': course.color }}
              role="button"
              tabIndex={course.status === 'active' ? 0 : -1}
              aria-label={course.status === 'active' ? `${course.title} - اضغط للبدء` : `${course.title} - قريباً`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && course.status === 'active') {
                  handleCourseSelect(course);
                }
              }}
            >
              {/* أيقونة المادة */}
              <div className="course-card__icon" style={{ color: course.color }}>
                {course.icon}
              </div>
              
              {/* عنوان المادة */}
              <h3 className="course-card__title">{course.title}</h3>
              
              {/* وصف المادة */}
              <p className="course-card__desc">{course.description}</p>
              
              {/* المحتوى حسب الحالة */}
              {course.status === 'active' ? (
                <>
                  {/* الإحصائيات */}
                  <div className="course-card__stats">
                    <div className="stat">
                      <Book size={16} aria-hidden="true" />
                      <span>{course.unitsCount} وحدات</span>
                    </div>
                    <div className="stat">
                      <span className="progress" style={{ color: course.color }}>
                        {course.progress}%
                      </span>
                      <span>تقدم</span>
                    </div>
                  </div>
                  
                  {/* زر البدء */}
                  <button 
                    className="course-card__btn" 
                    style={{ backgroundColor: course.color }}
                    aria-label={`ابدأ دراسة ${course.title}`}
                  >
                    ابدأ الدراسة
                  </button>
                </>
              ) : (
                /* حالة "قريباً" */
                <div className="course-card__soon">
                  <span role="img" aria-label="قريباً">🔜</span>
                  <span>قريباً</span>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </main>

      {/* ✅ التذييل */}
      <footer className="courses-footer">
        <p>
          🔐 <strong>Engineered by Duha Twam</strong> • 
          جامعة القدس المفتوحة © {new Date().getFullYear()}
        </p>
        <small className="text-muted">
          جميع الحقوق محفوظة • للاستخدام التعليمي فقط
        </small>
      </footer>
    </div>
  );
};

export default Courses;
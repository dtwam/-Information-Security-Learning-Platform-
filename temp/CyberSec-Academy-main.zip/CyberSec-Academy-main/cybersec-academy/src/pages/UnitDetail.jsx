
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Book, Clock, Target, CheckCircle, ChevronRight, 
  Copy, AlertTriangle, Terminal, Code, FileText, Lightbulb 
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

import { getUnitContent } from '../data/courseContent';
import useProgress from '../hooks/useProgress';
import './UnitDetail.css';

/**
 * ✅ مكون عرض قسم المحتوى
 */
const ContentSection = ({ section, unitColor }) => {
  const [copied, setCopied] = useState(false);
  
  const handleCopy = async (code) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('فشل النسخ:', err);
    }
  };

  switch (section.type) {
    case 'intro':
      return (
        <div className="intro-box">
          <ReactMarkdown>{section.content}</ReactMarkdown>
        </div>
      );
    
    case 'concept':
      return (
        <div className="concept-box">
          <ReactMarkdown>{section.content}</ReactMarkdown>
          {section.infoBox && (
            <div className={`info-box info-box--${section.infoBox.type}`}>
              <div className="info-box-title">
                <AlertTriangle size={20} />
                <strong>{section.infoBox.title}</strong>
              </div>
              <p>{section.infoBox.content}</p>
            </div>
          )}
          {section.tools && (
            <div className="tools-showcase">
              {section.tools.map((tool, index) => (
                <div key={index} className="tool-item">
                  <Terminal size={24} style={{ color: 'var(--primary-cyan)' }} />
                  <h4>{tool.name}</h4>
                  <p>{tool.desc}</p>
                </div>
              ))}
            </div>
          )}
          {section.diagram && (
            <div className="diagram-container">
              <div dangerouslySetInnerHTML={{ __html: section.diagram.svg }} />
            </div>
          )}
        </div>
      );
    
    case 'diagram-section':
      return (
        <div className="concept-box">
          <ReactMarkdown>{section.content}</ReactMarkdown>
          {section.diagram && (
            <div className="diagram-container">
              <div dangerouslySetInnerHTML={{ __html: section.diagram.svg }} />
            </div>
          )}
        </div>
      );
    
    case 'timeline':
      return (
        <div className="timeline">
          {section.items?.map((item, index) => (
            <div key={index} className="timeline-item">
              <div className="timeline-phase" style={{ backgroundColor: unitColor }}>
                {item.phase}
              </div>
              <div className="timeline-content">
                <h4>{item.title}</h4>
                <p>{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      );
    
    case 'content':
      return (
        <div className="content-section">
          <h3 className="section-title">{section.title}</h3>
          <div className="markdown-content">
            <ReactMarkdown
              components={{
                code({ node, inline, className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || '');
                  return !inline && match ? (
                    <SyntaxHighlighter
                      style={vscDarkPlus}
                      language={match[1]}
                      PreTag="div"
                      {...props}
                    >
                      {String(children).replace(/\n$/, '')}
                    </SyntaxHighlighter>
                  ) : (
                    <code className={className} {...props}>{children}</code>
                  );
                },
                table({ children }) {
                  return (
                    <div className="table-wrapper">
                      <table>{children}</table>
                    </div>
                  );
                }
              }}
            >
              {section.content}
            </ReactMarkdown>
          </div>
        </div>
      );
    
    case 'info-box':
      return (
        <div className={`info-box info-box--${section.variant || 'info'}`}>
          <ReactMarkdown>{section.content}</ReactMarkdown>
        </div>
      );
    
    case 'comparison':
      return (
        <div className="content-section">
          <h3 className="section-title">{section.title}</h3>
          <div className="comparison-grid">
            {section.items?.map((item, index) => (
              <div key={index} className="comparison-card">
                <h4 className="comparison-type">{item.type}</h4>
                <ul className="comparison-features">
                  {item.features?.map((feature, i) => (
                    <li key={i}>✓ {feature}</li>
                  ))}
                </ul>
                {item.examples && (
                  <>
                    <small>أمثلة:</small>
                    <ul className="comparison-examples">
                      {item.examples.map((ex, i) => (
                        <li key={i}>{ex}</li>
                      ))}
                    </ul>
                  </>
                )}
                {item.tools && (
                  <>
                    <small>أدوات:</small>
                    <ul className="comparison-tools">
                      {item.tools.map((tool, i) => (
                        <li key={i}>{tool}</li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    
    case 'code-example':
      return (
        <div className="content-section">
          <h3 className="section-title">{section.title}</h3>
          
          {section.code?.title && (
            <div className="code-header">
              <Code size={18} />
              <span>{section.code.title}</span>
              <button 
                className="copy-btn"
                onClick={() => handleCopy(section.code.code)}
                aria-label="نسخ الكود"
              >
                {copied ? <CheckCircle size={16} className="text-success" /> : <Copy size={16} />}
              </button>
            </div>
          )}
          
          <div className="code-block">
            <SyntaxHighlighter
              style={vscDarkPlus}
              language={section.code?.language || 'bash'}
              showLineNumbers
              wrapLines
            >
              {section.code?.code || ''}
            </SyntaxHighlighter>
          </div>
          
          {section.code?.explanation && (
            <div className="code-explanation">
              <Lightbulb size={16} />
              <p>{section.code.explanation}</p>
            </div>
          )}
        </div>
      );
    
    case 'alert':
      return (
        <div className={`alert-box alert-${section.variant || 'info'}`}>
          <div className="alert-header">
            <AlertTriangle size={20} />
            <strong>{section.title}</strong>
          </div>
          <div className="markdown-content">
            <ReactMarkdown>{section.content}</ReactMarkdown>
          </div>
        </div>
      );
    
    case 'tools-grid':
      return (
        <div className="content-section">
          <h3 className="section-title">{section.title}</h3>
          <div className="tools-grid">
            {section.items?.map((tool, index) => (
              <div key={index} className="tool-card">
                <span className="tool-icon">
                  <Terminal size={24} />
                </span>
                <h4>{tool.name || tool}</h4>
                <p>{tool.desc || tool}</p>
              </div>
            ))}
          </div>
        </div>
      );
    
    default:
      return (
        <div className="content-section">
          <h3 className="section-title">{section.title}</h3>
          <p>{section.content}</p>
        </div>
      );
  }
};

/**
 * ✅ مكون الاختبار القصير
 */
const UnitQuiz = ({ quiz, unitColor }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  
  const handleAnswer = (index) => {
    if (showResult) return;
    setSelectedAnswer(index);
  };
  
  const handleSubmit = () => {
    if (selectedAnswer === quiz[currentQuestion].correct) {
      setScore(score + 1);
    }
    setShowResult(true);
  };
  
  const handleNext = () => {
    if (currentQuestion < quiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };
  
  const question = quiz[currentQuestion];
  
  return (
    <div className="quiz-section" style={{ '--quiz-color': unitColor }}>
      <h3 className="section-title">
        <FileText size={20} />
        اختبار سريع
      </h3>
      
      <div className="quiz-progress">
        <span>سؤال {currentQuestion + 1} من {quiz.length}</span>
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${((currentQuestion + 1) / quiz.length) * 100}%` }}
          />
        </div>
      </div>
      
      <div className="quiz-question">
        <p className="question-text">{question.question}</p>
        
        <div className="quiz-options">
          {question.options.map((option, index) => (
            <button
              key={index}
              className={`quiz-option ${
                selectedAnswer === index ? 'selected' : ''
              } ${
                showResult && index === question.correct ? 'correct' : ''
              } ${
                showResult && selectedAnswer === index && index !== question.correct ? 'wrong' : ''
              }`}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
            >
              {option}
            </button>
          ))}
        </div>
      </div>
      
      {showResult && (
        <motion.div 
          className="quiz-result"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {selectedAnswer === question.correct ? (
            <p className="result-correct">✓ إجابة صحيحة!</p>
          ) : (
            <p className="result-wrong">✗ إجابة خاطئة</p>
          )}
          <p className="result-explanation">{question.explanation}</p>
        </motion.div>
      )}
      
      <div className="quiz-actions">
        {!showResult ? (
          <button 
            className="btn btn-primary"
            onClick={handleSubmit}
            disabled={selectedAnswer === null}
          >
            تحقق من الإجابة
          </button>
        ) : (
          <button 
            className="btn btn-primary"
            onClick={handleNext}
          >
            {currentQuestion < quiz.length - 1 ? 'السؤال التالي' : 'عرض النتيجة'}
          </button>
        )}
      </div>
    </div>
  );
};

/**
 * ✅ المكون الرئيسي لصفحة الوحدة
 */
const UnitDetail = () => {
  const { unitId } = useParams();
  const navigate = useNavigate();
  const { setUnitProgress, completeUnit } = useProgress();
  
  const unit = getUnitContent(unitId);
  const [activeSection, setActiveSection] = useState(0);
  const [completedSections, setCompletedSections] = useState([]);
  
  // ✅ Scroll to top when unit loads
  useEffect(() => {
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    
    setActiveSection(0);
    setCompletedSections([]);
    
    setTimeout(() => {
      const mainContent = document.querySelector('.unit-content');
      if (mainContent) {
        mainContent.scrollTop = 0;
        mainContent.focus();
      }
    }, 100);
  }, [unitId]);
  
  // ✅ Scroll to top when section changes
  useEffect(() => {
    setTimeout(() => {
      const mainContent = document.querySelector('.unit-content');
      if (mainContent) {
        mainContent.scrollTo({ top: 0, behavior: 'smooth' });
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 100);
  }, [activeSection]);
  
  // ✅ Update progress
  useEffect(() => {
    if (unit && !completedSections.includes(activeSection)) {
      setCompletedSections([...completedSections, activeSection]);
      const progress = Math.round((completedSections.length + 1) / unit.sections.length * 100);
      setUnitProgress(unitId, { progress });
      
      if (progress >= 100) {
        completeUnit(unitId);
      }
    }
  }, [activeSection, unit, unitId, setUnitProgress, completeUnit, completedSections]);
  
  // ✅ إذا لم توجد الوحدة
  if (!unit) {
    return (
      <div className="unit-not-found">
        <h2>⚠️ الوحدة غير موجودة</h2>
        <button className="btn" onClick={() => navigate('/dashboard')}>
          العودة للوحة التحكم
        </button>
      </div>
    );
  }
  
  const unitColor = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444'][unit.number % 5];
  const maxSection = (unit.sections?.length || 0) + (unit.quiz ? 1 : 0) - 1;
  
  return (
    <div className="unit-detail" data-theme="dark" style={{ '--unit-color': unitColor }}>
      
      {/* ✅ Header */}
      <header className="unit-header">
        <button className="back-btn" onClick={() => navigate('/dashboard')}>
          <ChevronRight size={20} />
          <span>العودة</span>
        </button>
        
        <div className="unit-header-info">
          <span className="unit-number">الوحدة {unit.number}</span>
          <h1>{unit.title}</h1>
          <p className="unit-description">{unit.description}</p>
          
          <div className="unit-meta">
            <span><Clock size={16} /> {unit.estimatedTime} دقيقة</span>
            <span><Target size={16} /> {unit.objectives?.length || 0} أهداف</span>
          </div>
        </div>
      </header>
      
      <div className="unit-layout">
        {/* ✅ Sidebar TOC */}
        <aside className="unit-toc">
          <h3>محتويات الوحدة</h3>
          <nav className="toc-nav">
            {unit.sections?.map((section, index) => (
              <button
                key={index}
                className={`toc-item ${activeSection === index ? 'active' : ''} ${completedSections.includes(index) ? 'completed' : ''}`}
                onClick={() => {
                  setActiveSection(index);
                  window.scrollTo(0, 0);
                }}
              >
                <span className="toc-number">{index + 1}</span>
                <span className="toc-title">{section.title}</span>
                {completedSections.includes(index) && (
                  <CheckCircle size={14} className="toc-check" />
                )}
              </button>
            ))}
            
            {unit.quiz && (
              <button
                className={`toc-item ${activeSection === unit.sections.length ? 'active' : ''}`}
                onClick={() => {
                  setActiveSection(unit.sections.length);
                  window.scrollTo(0, 0);
                }}
              >
                <span className="toc-number">📝</span>
                <span className="toc-title">اختبار سريع</span>
              </button>
            )}
          </nav>
          
          {/* ✅ Progress Bar */}
          <div className="toc-progress">
            <div className="progress-label">
              <span>تقدمك</span>
              <span>{Math.round((completedSections.length / (unit.sections.length + (unit.quiz ? 1 : 0))) * 100)}%</span>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill"
                style={{ width: `${(completedSections.length / (unit.sections.length + (unit.quiz ? 1 : 0))) * 100}%` }}
              />
            </div>
          </div>
        </aside>
        
        {/* ✅ Main Content - with scroll control */}
        <main 
          className="unit-content" 
          tabIndex={-1}
          style={{ scrollBehavior: 'smooth' }}
        >
          <AnimatePresence mode="wait">
            {activeSection < (unit.sections?.length || 0) ? (
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                <ContentSection 
                  section={unit.sections[activeSection]} 
                  unitColor={unitColor}
                />
              </motion.div>
            ) : unit.quiz ? (
              <motion.div
                key="quiz"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <UnitQuiz quiz={unit.quiz} unitColor={unitColor} />
              </motion.div>
            ) : null}
          </AnimatePresence>
          
          {/* ✅ Navigation Buttons */}
          <div className="unit-navigation">
            <button
              className="nav-btn"
              onClick={() => {
                setActiveSection(Math.max(0, activeSection - 1));
                window.scrollTo(0, 0);
              }}
              disabled={activeSection === 0}
            >
              <ChevronRight size={18} />
              <span>السابق</span>
            </button>
            
            <button
              className="nav-btn nav-btn-next"
              onClick={() => {
                if (activeSection < maxSection) {
                  setActiveSection(activeSection + 1);
                } else {
                  completeUnit(unit.id);
                  navigate('/dashboard');
                }
                window.scrollTo(0, 0);
              }}
            >
              <span>{activeSection >= maxSection ? 'إنهاء الوحدة' : 'التالي'}</span>
              <ChevronRight size={18} style={{ transform: 'rotate(180deg)' }} />
            </button>
          </div>
          
          {/* ✅ Summary */}
          {unit.summary && activeSection >= maxSection && (
            <motion.div
              className="summary-box"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h3 className="summary-title">
                <CheckCircle size={20} />
                ملخص الوحدة
              </h3>
              <ul className="key-points">
                {unit.summary.map((point, index) => (
                  <li key={index}>✓ {point}</li>
                ))}
              </ul>
            </motion.div>
          )}
          
          {/* ✅ Review Questions */}
          {unit.reviewQuestions && activeSection >= maxSection && (
            <motion.div
              className="review-questions"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h3 className="review-title">
                <FileText size={20} />
                أسئلة المراجعة
              </h3>
              {unit.reviewQuestions.map((question, index) => (
                <div key={index} className="question-item">
                  <span className="question-number">{index + 1}</span>
                  <span>{question}</span>
                </div>
              ))}
            </motion.div>
          )}
        </main>
      </div>
      
      {/* ✅ Footer */}
      <footer className="unit-footer">
        <p> <strong></strong>  جامعة القدس المفتوحة </p>
      </footer>
    </div>
  );
};

export default UnitDetail;
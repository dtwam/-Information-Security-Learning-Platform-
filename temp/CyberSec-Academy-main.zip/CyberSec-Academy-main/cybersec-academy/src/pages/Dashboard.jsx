/**
 * 📄 Dashboard.jsx
 * النسخة المعدلة: مقدمة → بوت → مساعد ذكي
 * 🔐 Engineered by Duha Twam
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip 
} from 'recharts';
import { 
  Book, Trophy, Target, Bot, Shield, Wifi, Terminal,
  ChevronDown, Award, Clock, CheckCircle, LayoutGrid,
  Code, Globe, Lock, Search, AlertTriangle, FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

// ✅ استيراد المكونات
import Navbar from '../components/Navbar';
import ProgressTracker from '../components/ProgressTracker';
import { AchievementBadgesGrid } from '../components/AchievementBadge';
import ChatInterface from '../components/AIAssistant/ChatInterface';

// ✅ استيراد البيانات والخطافات
import { getUnitsSummary } from '../data/courseContent';
import useProgress from '../hooks/useProgress';
import useTheme from '../hooks/useTheme';

// ✅ استيراد الأنماط
import '../styles/dashboard.css';

// ✅ بيانات المواد
const COURSES = [
  {
    id: 'security-software',
    name: 'برمجيات وتطبيقات أمن المعلومات',
    shortName: 'برمجيات الأمن',
    icon: <Book size={24} />,
    color: '#8b5cf6',
    gradient: 'linear-gradient(135deg, #8b5cf6, #06b6d4)',
    unitsCount: 7,
    description: 'اختبار اختراق الويب والتطبيقات الأمنية باستخدام Kali Linux',
    comingSoon: false,
    features: ['7 وحدات دراسية', 'مختبر عملي', 'اختبارات تفاعلية']
  }
];

// ✅ الوحدات الدراسية - التصميم الاحترافي
const UNITS_DATA = [
  {
    id: 'unit-1',
    number: '01',
    titleAr: 'أساسيات اختبار الاختراق',
    titleEn: 'Penetration Testing Fundamentals',
    description: 'مقدمة شاملة في مفاهيم اختبار الاختراق وأنواع التطبيقات ومبادئ الأمن السيبراني',
    topics: [
      'ما هو تطبيق الويب',
      'بروتوكول HTTP/HTTPS',
      'مراحل اختبار الاختراق',
      'نموذج Client-Server'
    ],
    tools: ['Nmap', 'Wireshark', 'Burp Suite'],
    icon: <Terminal size={32} />,
    color: '#06b6d4'
  },
  {
    id: 'unit-2',
    number: '02',
    titleAr: 'استطلاع سيرفر الويب',
    titleEn: 'Web Server Reconnaissance',
    description: 'تقنيات جمع المعلومات الاستباقية والتفاعلية عن الأهداف والأنظمة',
    topics: [
      'الاستطلاع السلبي والنشط',
      'الذكاء من المصادر المفتوحة OSINT',
      'فحص DNS',
      'تحليل robots.txt'
    ],
    tools: ['theHarvester', 'Shodan', 'dnsenum'],
    icon: <Search size={32} />,
    color: '#3b82f6'
  },
  {
    id: 'unit-3',
    number: '03',
    titleAr: 'البحث عن الثغرات',
    titleEn: 'Vulnerability Assessment',
    description: 'اكتشاف وتحليل الثغرات الأمنية واستخدام أطر العمل المتقدمة',
    topics: [
      'الفرق بين Vulnerability و Exploit',
      'Metasploit Framework',
      'Reverse Shell techniques',
      'إدارة الجلسات الخلفية'
    ],
    tools: ['Metasploit', 'Nessus', 'OpenVAS'],
    icon: <AlertTriangle size={32} />,
    color: '#f59e0b'
  },
  {
    id: 'unit-4',
    number: '04',
    titleAr: 'استطلاع تطبيق الويب',
    titleEn: 'Web Application Reconnaissance',
    description: 'تحليل متعمق لتطبيقات الويب واكتشاف هيكلها ونقاط الدخول',
    topics: [
      'Proxy interception',
      'Spidering و crawling',
      'Web scanners الآلية',
      'تحليل البنية التحتية'
    ],
    tools: ['Burp Suite', 'OWASP ZAP', 'Nikto'],
    icon: <Globe size={32} />,
    color: '#10b981'
  },
  {
    id: 'unit-5',
    number: '05',
    titleAr: 'ثغرات الحقن',
    titleEn: 'Injection Attacks',
    description: 'دراسة شاملة لهجمات الحقن SQL و Command Injection والدفاع ضدها',
    topics: [
      'SQL Injection بأنواعها',
      'Command Injection',
      'Web Shells',
      'طرق الحماية والتأمين'
    ],
    tools: ['sqlmap', 'sqlninja', 'Websploit'],
    icon: <Code size={32} />,
    color: '#ef4444'
  },
  {
    id: 'unit-6',
    number: '06',
    titleAr: 'هجمات المصادقة',
    titleEn: 'Authentication Attacks',
    description: 'استهداف أنظمة المصادقة والجلسات وطرق الحماية المتقدمة',
    topics: [
      'Brute Force attacks',
      'Session Hijacking',
      'Path Traversal',
      'CSRF attacks'
    ],
    tools: ['Hydra', 'John', 'Hashcat'],
    icon: <Lock size={32} />,
    color: '#8b5cf6'
  },
  {
    id: 'unit-7',
    number: '07',
    titleAr: 'مهاجمة مستخدم الويب',
    titleEn: 'Web User Attacks',
    description: 'هجمات XSS والهندسة الاجتماعية واستهداف المستخدمين النهائيين',
    topics: [
      'Cross-Site Scripting XSS',
      'Social Engineering',
      'Phishing attacks',
      'Client-side exploitation'
    ],
    tools: ['SET', 'BeEF', 'XSSer'],
    icon: <Shield size={32} />,
    color: '#ec4899'
  }
];

// ✅ مكون الروبوت المبتسم - كامل وفعال
const InlineAIBot = () => {
  const [eyePos, setEyePos] = useState({ x: 0, y: 0 });
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const handleMove = (e) => {
      const x = (e.clientX - window.innerWidth / 2) / 50;
      const y = (e.clientY - window.innerHeight / 2) / 50;
      setEyePos({ 
        x: Math.max(-3, Math.min(3, x)), 
        y: Math.max(-3, Math.min(3, y)) 
      });
    };
    window.addEventListener('mousemove', handleMove);
    return () => window.removeEventListener('mousemove', handleMove);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 150);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="ai-bot-professional">
      <svg viewBox="0 0 200 200" className="ai-bot-svg" aria-label="الروبوت المساعد">
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--primary-blue)" stopOpacity="0.3"/>
            <stop offset="100%" stopColor="var(--accent-cyan)" stopOpacity="0.3"/>
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="90" fill="url(#grad)" className="ai-bot-aura"/>
        <rect x="60" y="70" width="80" height="70" rx="12" fill="var(--bg-secondary)" stroke="var(--primary-blue)" strokeWidth="2"/>
        <circle cx="100" cy="55" r="32" fill="var(--bg-secondary)" stroke="var(--primary-blue)" strokeWidth="2"/>
        <circle cx={88 + eyePos.x} cy={50 + eyePos.y} r={blink ? 0.5 : 6} fill="var(--primary-blue)"/>
        {blink && <line x1="84" y1="50" x2="92" y2="50" stroke="var(--primary-blue)" strokeWidth="2" strokeLinecap="round"/>}
        <circle cx={112 + eyePos.x} cy={50 + eyePos.y} r={blink ? 0.5 : 6} fill="var(--primary-blue)"/>
        {blink && <line x1="108" y1="50" x2="116" y2="50" stroke="var(--primary-blue)" strokeWidth="2" strokeLinecap="round"/>}
        <path d="M 85 65 Q 100 75 115 65" stroke="var(--accent-green)" strokeWidth="3" fill="none" strokeLinecap="round"/>
        <line x1="100" y1="25" x2="100" y2="10" stroke="var(--primary-blue)" strokeWidth="3"/>
        <circle cx="100" cy="8" r="5" fill="var(--accent-cyan)" className="ai-bot-antenna"/>
        <path d="M 60 90 Q 45 100 50 115" stroke="var(--primary-blue)" strokeWidth="4" fill="none" strokeLinecap="round"/>
        <path d="M 140 90 Q 155 100 150 115" stroke="var(--primary-blue)" strokeWidth="4" fill="none" strokeLinecap="round"/>
      </svg>
      <p className="ai-bot-text">👋 أهلاً بك! أنا مساعدك الذكي</p>
    </div>
  );
};

// ✅ مكون بطاقة الوحدة الاحترافية
const ProfessionalUnitCard = ({ unit, progress, onClick }) => {
  const isCompleted = progress >= 100;
  
  return (
    <motion.div
      className="professional-unit-card"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -8, transition: { duration: 0.3 } }}
      onClick={onClick}
      role="button"
      tabIndex={0}
      style={{ '--unit-color': unit.color }}
    >
      <div className="unit-number-badge" style={{ background: unit.color }}>
        {unit.number}
      </div>
      
      <div className="unit-header">
        <div className="unit-icon" style={{ color: unit.color }}>
          {unit.icon}
        </div>
        <div className="unit-titles">
          <h3 className="unit-title-ar">{unit.titleAr}</h3>
          <p className="unit-title-en">{unit.titleEn}</p>
        </div>
      </div>
      
      <p className="unit-description">{unit.description}</p>
      
      <div className="unit-topics">
        <h4 className="topics-title">
          <FileText size={16} />
          المواضيع الرئيسية
        </h4>
        <ul className="topics-list">
          {unit.topics.map((topic, index) => (
            <li key={index} className="topic-item">
              <CheckCircle size={14} className="topic-check" />
              <span>{topic}</span>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="unit-tools">
        <h4 className="tools-title">
          <Terminal size={16} />
          الأدوات المستخدمة
        </h4>
        <div className="tools-tags">
          {unit.tools.map((tool, index) => (
            <span key={index} className="tool-tag">{tool}</span>
          ))}
        </div>
      </div>
      
      <div className="unit-progress-section">
        <div className="unit-progress-bar">
          <div 
            className="unit-progress-fill"
            style={{ width: `${progress}%`, background: unit.color }}
          />
        </div>
        <div className="unit-progress-info">
          <span className="progress-percentage">{progress}%</span>
          {isCompleted && (
            <span className="completed-badge">
              <CheckCircle size={14} />
              مكتمل
            </span>
          )}
        </div>
      </div>
      
      <button className="unit-start-btn" style={{ background: unit.color }}>
        {isCompleted ? 'مراجعة الوحدة' : progress > 0 ? 'متابعة التعلم' : 'ابدأ الآن'}
        <ChevronDown size={18} style={{ transform: 'rotate(180deg)' }} />
      </button>
    </motion.div>
  );
};

const Dashboard = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  const { progress, stats, resetProgress } = useProgress();
  const navigate = useNavigate();
  
  const [selectedCourse, setSelectedCourse] = useState(COURSES[0]);
  const [showCourseSelector, setShowCourseSelector] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  
  const unitsWithProgress = useMemo(() => {
    return getUnitsSummary().map(unit => {
      const prog = progress.units?.find(u => u.id === unit.id);
      return {
        ...unit,
        progress: prog?.progress || 0,
        completed: prog?.completed || false
      };
    });
  }, [progress.units]);
  
  const chartData = useMemo(() => {
    const completed = unitsWithProgress.filter(u => u.completed).length;
    const inProgress = unitsWithProgress.filter(u => u.progress > 0 && !u.completed).length;
    const notStarted = unitsWithProgress.length - completed - inProgress;
    
    return [
      { name: 'مكتملة', value: completed, color: '#00ff9d' },
      { name: 'قيد التقدم', value: inProgress, color: '#00d4ff' },
      { name: 'لم تبدأ', value: notStarted, color: '#1f2937' }
    ].filter(item => item.value > 0);
  }, [unitsWithProgress]);
  
  const handleSearch = (query) => console.log('Search:', query);
  
  const handleCourseSelect = (course) => {
    if (!course.comingSoon) {
      setSelectedCourse(course);
      setShowCourseSelector(false);
    }
  };
  
  const handleUnitSelect = (unitId) => {
    navigate(`/unit/${unitId}`);
  };
  
  return (
    <div className="dashboard-professional" data-theme={isDarkMode ? 'dark' : 'light'}>
      
      {/* ✅ Navbar */}
      <Navbar 
        onSearch={handleSearch}
        onToggleTheme={toggleTheme}
        isDarkMode={isDarkMode}
        userInfo={{ name: 'طالب الأمن السيبراني' }}
        courseSelector={
          <button 
            className="navbar__course-btn"
            onClick={() => setShowCourseSelector(true)}
            style={{ '--btn-color': selectedCourse.color }}
          >
            <LayoutGrid size={18} />
            <span className="navbar__course-name">{selectedCourse.shortName}</span>
            <ChevronDown size={16} />
          </button>
        }
      />
      
      <main className="dashboard-main-professional">
        
        {/* ✅ 1️⃣ الكلام والمقدمة في الأعلى */}
        <section className="intro-text-section">
          <div className="intro-text-content">
            <h1 className="intro-title">
              {selectedCourse.name}
            </h1>
            <p className="intro-subtitle">جامعة القدس المفتوحة</p>
            <p className="intro-description">{selectedCourse.description}</p>
          </div>
        </section>
        
        {/* ✅ 2️⃣ البوت المبتسم تحت الكلام */}
        <section className="bot-section">
          <InlineAIBot />
        </section>
        
        {/* ✅ 3️⃣ المساعد الذكي (الآيجينت) تحت البوت */}
        <section className="ai-agent-section">
          <ChatInterface />
        </section>
        
        {/* ✅ تبويبات التنقل */}
        <div className="content-tabs">
          <button 
            className={`content-tab ${activeTab === 'overview' ? 'content-tab--active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            <Book size={18} />
            <span>الوحدات الدراسية</span>
          </button>
          <button 
            className={`content-tab ${activeTab === 'progress' ? 'content-tab--active' : ''}`}
            onClick={() => setActiveTab('progress')}
          >
            <Target size={18} />
            <span>التقدم</span>
          </button>
        </div>
        
        {/* ✅ المحتوى حسب التبويب */}
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.section
              key="units"
              className="units-section"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="section-intro">
                <h2 className="section-title">
                  <Book size={24} />
                  الوحدات التعليمية | Learning Modules
                </h2>
                <p className="section-description">
                  اضغط على أي وحدة للتعمق في المحتوى التفاعلي — Click any unit to explore interactive content
                </p>
              </div>
              
              <div className="professional-units-grid">
                {UNITS_DATA.map((unit) => {
                  const unitProgress = unitsWithProgress.find(u => u.id === unit.id);
                  return (
                    <ProfessionalUnitCard
                      key={unit.id}
                      unit={unit}
                      progress={unitProgress?.progress || 0}
                      onClick={() => handleUnitSelect(unit.id)}
                    />
                  );
                })}
              </div>
            </motion.section>
          )}
          
          {activeTab === 'progress' && (
            <motion.section
              key="progress"
              className="content-section"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <ProgressTracker progress={{ units: unitsWithProgress }} onReset={resetProgress}/>
              <AchievementBadgesGrid userData={progress.achievements}/>
            </motion.section>
          )}
        </AnimatePresence>
        
      </main>
      
      {/* ✅ Footer */}
      <footer className="professional-footer">
        <div className="footer-content">
          
           
          <p className="footer-rights">
            جميع الحقوق محفوظة | Educational Purpose Only
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
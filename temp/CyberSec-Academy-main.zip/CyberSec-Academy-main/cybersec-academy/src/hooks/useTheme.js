
import { useState, useEffect, useCallback } from 'react';

const THEME_KEY = 'cybersec_academy_theme';

const useTheme = () => {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // ✅ Check localStorage first
    const saved = localStorage.getItem(THEME_KEY);
    if (saved) {
      return saved === 'dark';
    }
    // ✅ Then check system preference
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // ✅ Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.setAttribute('data-theme', 'light');
    }
    localStorage.setItem(THEME_KEY, isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  // ✅ Toggle theme
  const toggleTheme = useCallback(() => {
    setIsDarkMode(prev => !prev);
  }, []);

  // ✅ Set specific theme
  const setTheme = useCallback((theme) => {
    setIsDarkMode(theme === 'dark');
  }, []);

  // ✅ Listen to system preference changes
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e) => {
      const saved = localStorage.getItem(THEME_KEY);
      if (!saved) {
        setIsDarkMode(e.matches);
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  return {
    isDarkMode,
    toggleTheme,
    setTheme
  };
};

export default useTheme;
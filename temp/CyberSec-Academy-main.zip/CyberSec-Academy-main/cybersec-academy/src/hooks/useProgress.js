
import { useState, useEffect, useCallback, useMemo } from 'react';

const PROGRESS_KEY = 'cybersec_academy_progress_v1';

/**
 * حفظ التقدم في LocalStorage
 */
const saveProgress = (data) => {
  try {
    const dataWithMeta = {
      ...data,
      savedAt: new Date().toISOString(),
    };
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(dataWithMeta));
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ التقدم:', error);
    return false;
  }
};

/**
 * تحميل التقدم من LocalStorage
 */
const loadProgress = () => {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return null;
    
    const data = JSON.parse(raw);
    return data;
  } catch (error) {
    console.error('❌ فشل تحميل التقدم:', error);
    return null;
  }
};

/**
 * إعادة تعيين التقدم
 */
const resetProgress = () => {
  try {
    localStorage.removeItem(PROGRESS_KEY);
    return true;
  } catch (error) {
    console.error('❌ فشل إعادة التعيين:', error);
    return false;
  }
};

/**
 * الخطاف الرئيسي
 */
const useProgress = () => {
  const [progress, setProgress] = useState(() => {
    try {
      return loadProgress() || {
        units: [],
        achievements: {},
        lastUpdated: new Date().toISOString(),
        version: '1.0'
      };
    } catch (error) {
      console.error('❌ فشل تحميل التقدم:', error);
      return { units: [], achievements: {}, lastUpdated: new Date().toISOString(), version: '1.0' };
    }
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  
  /**
   * تحديث تقدم وحدة معينة
   */
  const updateUnitProgress = useCallback((unitId, updates) => {
    try {
      setIsLoading(true);
      setError(null);
      
      setProgress(prev => {
        const updatedUnits = prev.units.map(unit => 
          unit.id === unitId ? { ...unit, ...updates } : unit
        );
        
        if (!updatedUnits.some(u => u.id === unitId)) {
          updatedUnits.push({ id: unitId, progress: 0, completed: false, ...updates });
        }
        
        const newProgress = {
          ...prev,
          units: updatedUnits,
          lastUpdated: new Date().toISOString()
        };
        
        saveProgress(newProgress);
        return newProgress;
      });
      
    } catch (err) {
      console.error('❌ فشل تحديث التقدم:', err);
      setError('فشل حفظ التقدم.');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  /**
   * تعيين وحدة كمكتملة
   */
  const completeUnit = useCallback((unitId) => {
    updateUnitProgress(unitId, { completed: true, progress: 100 });
  }, [updateUnitProgress]);
  
  /**
   * تحديث نسبة التقدم
   */
  const setUnitProgress = useCallback((unitId, percentage) => {
    const clamped = Math.max(0, Math.min(100, percentage));
    updateUnitProgress(unitId, { 
      progress: clamped,
      completed: clamped >= 100
    });
  }, [updateUnitProgress]);
  
  /**
   * تتبع استخدام الأوامر
   */
  const trackCommandUsage = useCallback((command) => {
    setProgress(prev => {
      const cmdCount = prev.achievements?.commandUsage?.[command] || 0;
      const uniqueCommands = prev.achievements?.uniqueCommands || [];
      
      const newAchievements = {
        ...prev.achievements,
        commandUsage: {
          ...prev.achievements?.commandUsage,
          [command]: cmdCount + 1
        },
        uniqueCommands: uniqueCommands.includes(command) 
          ? uniqueCommands 
          : [...uniqueCommands, command]
      };
      
      const newProgress = {
        ...prev,
        achievements: newAchievements,
        lastUpdated: new Date().toISOString()
      };
      
      saveProgress(newProgress);
      return newProgress;
    });
  }, []);
  
  /**
   * فتح شارة إنجاز
   */
  const unlockAchievement = useCallback((badgeId) => {
    setProgress(prev => {
      if (prev.achievements?.[badgeId]?.unlocked) {
        return prev;
      }
      
      const newAchievements = {
        ...prev.achievements,
        [badgeId]: {
          ...(prev.achievements?.[badgeId] || {}),
          unlocked: true,
          unlockedAt: new Date().toISOString()
        }
      };
      
      const newProgress = {
        ...prev,
        achievements: newAchievements,
        lastUpdated: new Date().toISOString()
      };
      
      saveProgress(newProgress);
      return newProgress;
    });
  }, []);
  
  /**
   * إعادة تعيين التقدم
   */
  const handleReset = useCallback(() => {
    try {
      resetProgress();
      setProgress({
        units: [],
        achievements: {},
        lastUpdated: new Date().toISOString(),
        version: '1.0'
      });
      return true;
    } catch (err) {
      console.error('❌ فشل إعادة التعيين:', err);
      return false;
    }
  }, []);
  
  /**
   * حساب الإحصائيات
   */
  const stats = useMemo(() => {
    const totalUnits = progress.units?.length || 0;
    const completedUnits = progress.units?.filter(u => u.completed)?.length || 0;
    const totalProgress = progress.units?.reduce((sum, u) => sum + (u.progress || 0), 0) || 0;
    const averageProgress = totalUnits > 0 ? Math.round(totalProgress / totalUnits) : 0;
    const unlockedBadges = Object.values(progress.achievements || {}).filter(a => a.unlocked).length;
    
    return {
      totalUnits,
      completedUnits,
      averageProgress,
      unlockedBadges,
      lastUpdated: progress.lastUpdated
    };
  }, [progress]);
  
  return {
    progress,
    stats,
    isLoading,
    error,
    updateUnitProgress,
    completeUnit,
    setUnitProgress,
    trackCommandUsage,
    unlockAchievement,
    resetProgress: handleReset
  };
};

export default useProgress;
export { saveProgress, loadProgress, resetProgress };
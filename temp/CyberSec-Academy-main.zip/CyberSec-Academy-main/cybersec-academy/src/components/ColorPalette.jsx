/**
 * 📄 ColorPalette.jsx
 * @module components/ColorPalette
 */

import React, { useState, useCallback } from 'react';
import { Copy, Check, Palette } from 'lucide-react';
import PropTypes from 'prop-types';
import { motion, AnimatePresence } from 'framer-motion';
import '../styles/colorPalette.css';

/**
 * نظام الألوان الكامل
 */
const COLOR_SYSTEM = {
  backgrounds: {
    label: '🌑 الخلفيات',
    colors: {
      'bg-primary': { value: '#0a0e17', name: 'أساسي', usage: 'خلفية الصفحة الرئيسية' },
      'bg-secondary': { value: '#111827', name: 'ثانوي', usage: 'خلفية البطاقات والعناصر' },
      'bg-tertiary': { value: '#1f2937', name: 'ثالث', usage: 'الحواف والفواصل' },
      'bg-card': { value: '#161e2e', name: 'البطاقات', usage: 'خلفية البطاقات المميزة' },
      'bg-hover': { value: '#1e293b', name: 'تحويم', usage: 'حالة التحويم على العناصر' }
    }
  },
  accents: {
    label: '🌟 ألوان التمييز',
    colors: {
      'accent-cyan': { value: '#00d4ff', name: 'سماوي', usage: 'الروابط والتقدم والتمييز' },
      'accent-green': { value: '#00ff9d', name: 'أخضر نيون', usage: 'الإنجاز والنجاح' },
      'accent-purple': { value: '#7c3aed', name: 'بنفسجي', usage: 'العناصر الخاصة والأزرار' },
      'accent-red': { value: '#ef4444', name: 'أحمر', usage: 'التحذيرات والأخطاء' },
      'accent-yellow': { value: '#f59e0b', name: 'أصفر', usage: 'التنبيهات والتحذيرات' },
      'accent-blue': { value: '#3b82f6', name: 'أزرق', usage: 'المعلومات والروابط الثانوية' }
    }
  },
  text: {
    label: '📝 النصوص',
    colors: {
      'text-primary': { value: '#f1f5f9', name: 'رئيسي', usage: 'العناوين والنصوص الأساسية' },
      'text-secondary': { value: '#94a3b8', name: 'ثانوي', usage: 'النصوص الوصفية' },
      'text-muted': { value: '#64748b', name: 'خافت', usage: 'النصوص الثانوية والتلميحات' },
      'text-inverse': { value: '#0a0e17', name: 'عكسي', usage: 'النص على الخلفيات الفاتحة' }
    }
  },
  code: {
    label: '💻 تمييز الأكواد',
    colors: {
      'code-bg': { value: '#0d1117', name: 'خلفية الكود', usage: 'محرر الأكواد' },
      'keyword': { value: '#ff7b72', name: 'كلمات مفتاحية', usage: 'كلمات البرمجة المحجوزة' },
      'string': { value: '#a5d6ff', name: 'نصوص', usage: 'السلاسل النصية' },
      'function': { value: '#d2a8ff', name: 'دوال', usage: 'أسماء الدوال' },
      'comment': { value: '#8b949e', name: 'تعليقات', usage: 'تعليقات الكود' },
      'operator': { value: '#ff7b72', name: 'مشغلات', usage: 'العمليات الرياضية والمنطقية' },
      'variable': { value: '#79c0ff', name: 'متغيرات', usage: 'أسماء المتغيرات' },
      'number': { value: '#79c0ff', name: 'أرقام', usage: 'القيم العددية' }
    }
  }
};

/**
 * مكون عرض لون فردي
 * @param {Object} props - خصائص المكون
 * @param {string} props.colorKey - مفتاح اللون
 * @param {Object} props.colorData - بيانات اللون
 * @param {string} props.category - فئة اللون
 */
const ColorItem = ({ colorKey, colorData, category }) => {
  const [copied, setCopied] = useState(false);
  
  /**
   * نسخ قيمة اللون
   */
  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(colorData.value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('فشل نسخ اللون:', err);
    }
  }, [colorData.value]);
  
  return (
    <motion.div
      className="color-item"
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      role="button"
      tabIndex={0}
      onClick={handleCopy}
      onKeyDown={(e) => e.key === 'Enter' && handleCopy()}
      aria-label={`نسخ ${colorData.name}: ${colorData.value}`}
      title={`انسخ: ${colorData.value}`}
    >
      {/* ✅ معاينة اللون */}
      <div 
        className="color-item__preview"
        style={{ backgroundColor: colorData.value }}
        aria-hidden="true"
      >
        {/* ✅ نص تجريبي للعرض */}
        <span className="color-item__preview-text" style={{ 
          color: ['#0a0e17', '#111827', '#1f2937'].includes(colorData.value) 
            ? '#f1f5f9' : '#0a0e17' 
        }}>
          Aa
        </span>
      </div>
      
      {/* ✅ معلومات اللون */}
      <div className="color-item__info">
        <div className="color-item__header">
          <span className="color-item__name">{colorData.name}</span>
          <motion.button
            className="color-item__copy"
            onClick={(e) => {
              e.stopPropagation();
              handleCopy();
            }}
            aria-label={copied ? 'تم النسخ' : 'نسخ الكود'}
            whileTap={{ scale: 0.9 }}
          >
            <AnimatePresence mode="wait">
              {copied ? (
                <motion.span
                  key="check"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                >
                  <Check size={14} className="text-success" />
                </motion.span>
              ) : (
                <motion.span
                  key="copy"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                >
                  <Copy size={14} />
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
        
        <code className="color-item__value">{colorData.value}</code>
        <small className="color-item__usage text-muted">{colorData.usage}</small>
        
        {/* ✅ متغير CSS */}
        <code className="color-item__var">
          var(--{category}-{colorKey})
        </code>
      </div>
    </motion.div>
  );
};

/**
 * مكون لوحة الألوان الرئيسية
 * @param {Object} props - خصائص المكون
 * @param {boolean} props.isOpen - حالة فتح اللوحة
 * @param {Function} props.onClose - دالة الإغلاق
 */
const ColorPalette = ({ isOpen, onClose }) => {
  const [activeCategory, setActiveCategory] = useState('backgrounds');
  
  if (!isOpen) return null;
  
  return (
    <motion.div
      className="color-palette-modal"
      role="dialog"
      aria-modal="true"
      aria-labelledby="palette-title"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* ✅ خلفية معتمة */}
      <div 
        className="color-palette__overlay"
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* ✅ محتوى اللوحة */}
      <motion.div
        className="color-palette__content"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        transition={{ type: 'spring', damping: 25 }}
      >
        {/* ✅ رأس اللوحة */}
        <header className="color-palette__header">
          <div>
            <Palette size={24} aria-hidden="true" />
            <h2 id="palette-title">لوحة الألوان السيبرانية</h2>
          </div>
          <button
            className="color-palette__close"
            onClick={onClose}
            aria-label="إغلاق لوحة الألوان"
          >
            ✕
          </button>
        </header>
        
        {/* ✅ تبويبات الفئات */}
        <nav className="color-palette__tabs" role="tablist">
          {Object.entries(COLOR_SYSTEM).map(([key, category]) => (
            <button
              key={key}
              className={`color-palette__tab ${activeCategory === key ? 'active' : ''}`}
              onClick={() => setActiveCategory(key)}
              role="tab"
              aria-selected={activeCategory === key}
              aria-controls={`panel-${key}`}
            >
              {category.label}
            </button>
          ))}
        </nav>
        
        {/* ✅ محتوى الفئات */}
        <div className="color-palette__panel">
          {Object.entries(COLOR_SYSTEM).map(([key, category]) => (
            <div
              key={key}
              id={`panel-${key}`}
              role="tabpanel"
              hidden={activeCategory !== key}
              className={`color-palette__grid ${activeCategory === key ? 'active' : ''}`}
            >
              {Object.entries(category.colors).map(([colorKey, colorData]) => (
                <ColorItem
                  key={colorKey}
                  colorKey={colorKey}
                  colorData={colorData}
                  category={key}
                />
              ))}
            </div>
          ))}
        </div>
        
        {/* ✅ تذييل */}
        <footer className="color-palette__footer">
          <small className="text-muted">
            💡 انقر على أي لون لنسخ قيمته • 
            جميع الألوان متوافقة مع WCAG 2.1 AA
          </small>
          <div className="color-palette__credit">
            🔐 Engineered by Duha Twam
          </div>
        </footer>
      </motion.div>
    </motion.div>
  );
};

// ✅ التحقق من أنواع الخصائص
ColorItem.propTypes = {
  colorKey: PropTypes.string.isRequired,
  colorData: PropTypes.shape({
    value: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    usage: PropTypes.string.isRequired
  }).isRequired,
  category: PropTypes.string.isRequired
};

ColorPalette.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired
};

export default ColorPalette;
export { ColorItem, COLOR_SYSTEM };
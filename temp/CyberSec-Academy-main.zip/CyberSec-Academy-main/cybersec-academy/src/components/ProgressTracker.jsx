/**
 * 📄 ProgressTracker.jsx
 * مكون تتبع التقدم العام والوحدات
 * @module components/ProgressTracker
 */

import React, { useMemo } from 'react';
import { Trophy, Target, Award, RefreshCw } from 'lucide-react';
import PropTypes from 'prop-types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { motion } from 'framer-motion';
import '../styles/dashboard.css';

/**
 * مكون تتبع التقدم
 * @param {Object} props - خصائص المكون
 * @param {Object} props.progress - بيانات التقدم
 * @param {Function} props.onReset - دالة إعادة التعيين
 */
const ProgressTracker = ({ progress, onReset }) => {
  // ✅ حساب الإحصائيات
  const stats = useMemo(() => {
    const units = progress?.units || [];
    const total = units.length;
    const completed = units.filter(u => u.completed).length;
    const inProgress = units.filter(u => u.progress > 0 && !u.completed).length;
    const notStarted = total - completed - inProgress;
    const overallPercentage = total > 0 
      ? Math.round((units.reduce((sum, u) => sum + u.progress, 0) / total)) 
      : 0;
    
    return { total, completed, inProgress, notStarted, overallPercentage };
  }, [progress]);
  
  // ✅ بيانات المخطط الدائري
  const chartData = useMemo(() => [
    { name: 'مكتملة', value: stats.completed, color: '#00ff9d' },
    { name: 'قيد التقدم', value: stats.inProgress, color: '#00d4ff' },
    { name: 'لم تبدأ', value: stats.notStarted, color: '#1f2937' }
  ].filter(item => item.value > 0), [stats]);
  
  // ✅ تخصيص tooltip للمخطط
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload?.length) {
      const data = payload[0].payload;
      return (
        <div className="chart-tooltip">
          <p style={{ margin: 0, color: data.color }}>
            <strong>{data.name}</strong>: {data.value} وحدات
          </p>
        </div>
      );
    }
    return null;
  };
  
  /**
   * معالجة إعادة تعيين التقدم
   * مع تأكيد من المستخدم
   */
  const handleReset = () => {
    if (window.confirm('⚠️ هل أنت متأكد من إعادة تعيين كل التقدم؟\nلا يمكن التراجع عن هذا الإجراء.')) {
      onReset?.();
    }
  };
  
  return (
    <motion.section 
      className="progress-tracker"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* ✅ رأس القسم */}
      <header className="progress-tracker__header">
        <Target size={20} aria-hidden="true" />
        <h2>تتبع التقدم</h2>
        <button
          className="progress-tracker__reset"
          onClick={handleReset}
          aria-label="إعادة تعيين التقدم"
          title="إعادة تعيين التقدم"
        >
          <RefreshCw size={16} aria-hidden="true" />
          <span className="sr-only">إعادة تعيين</span>
        </button>
      </header>
      
      {/* ✅ البطاقات الإحصائية */}
      <div className="progress-tracker__stats">
        <motion.div 
          className="stat-card"
          whileHover={{ y: -4 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="stat-card__icon" style={{ color: 'var(--accent-green)' }}>
            <Trophy size={24} aria-hidden="true" />
          </div>
          <div className="stat-card__content">
            <span className="stat-card__value">{stats.completed}</span>
            <span className="stat-card__label">وحدات مكتملة</span>
          </div>
        </motion.div>
        
        <motion.div 
          className="stat-card"
          whileHover={{ y: -4 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="stat-card__icon" style={{ color: 'var(--accent-cyan)' }}>
            <Target size={24} aria-hidden="true" />
          </div>
          <div className="stat-card__content">
            <span className="stat-card__value">{stats.inProgress}</span>
            <span className="stat-card__label">قيد التقدم</span>
          </div>
        </motion.div>
        
        <motion.div 
          className="stat-card"
          whileHover={{ y: -4 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="stat-card__icon" style={{ color: 'var(--accent-purple)' }}>
            <Award size={24} aria-hidden="true" />
          </div>
          <div className="stat-card__content">
            <span className="stat-card__value">{stats.overallPercentage}%</span>
            <span className="stat-card__label">التقدم الكلي</span>
          </div>
        </motion.div>
      </div>
      
      {/* ✅ المخطط الدائري */}
      <div className="progress-tracker__chart">
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              labelLine={false}
            >
              {chartData.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color}
                  stroke="var(--bg-primary)"
                  strokeWidth={2}
                />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              iconType="circle"
              formatter={(value) => <span style={{ color: 'var(--text-secondary)' }}>{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
      
      {/* ✅ شريط التقدم الكلي */}
      <div className="progress-tracker__overall">
        <div className="progress-tracker__overall-header">
          <span>التقدم العام في المادة</span>
          <span aria-label={`${stats.overallPercentage}% مكتمل`}>
            {stats.overallPercentage}%
          </span>
        </div>
        <div 
          className="progress-tracker__overall-bar"
          role="progressbar"
          aria-valuenow={stats.overallPercentage}
          aria-valuemin="0"
          aria-valuemax="100"
          aria-label="شريط التقدم العام"
        >
          <motion.div
            className="progress-tracker__overall-fill"
            initial={{ width: 0 }}
            animate={{ width: `${stats.overallPercentage}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            style={{
              background: `linear-gradient(90deg, var(--accent-cyan), var(--accent-green))`
            }}
          />
        </div>
      </div>
      
      {/* ✅ تذييل */}
      <footer className="progress-tracker__footer">
        <small className="text-muted">
          💡 يتم حفظ التقدم تلقائيًا في متصفحك
        </small>
      </footer>
    </motion.section>
  );
};

// ✅ التحقق من أنواع الخصائص
ProgressTracker.propTypes = {
  progress: PropTypes.shape({
    units: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.string,
      progress: PropTypes.number,
      completed: PropTypes.bool
    }))
  }),
  onReset: PropTypes.func
};

ProgressTracker.defaultProps = {
  progress: { units: [] },
  onReset: () => {}
};

export default React.memo(ProgressTracker);
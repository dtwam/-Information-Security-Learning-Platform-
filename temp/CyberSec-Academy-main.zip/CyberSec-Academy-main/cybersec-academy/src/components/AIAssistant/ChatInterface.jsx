
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageCircle, X, Send, Bot, User, 
  Loader, Lightbulb, Sparkles, Minimize2, Maximize2
} from 'lucide-react';
import { askAssistant } from '../../services/aiAssistant';
import './ChatInterface.css';

const ChatMessage = ({ message, isBot }) => (
  <motion.div
    className={`chat-message ${isBot ? 'chat-message--bot' : 'chat-message--user'}`}
    initial={{ opacity: 0, x: isBot ? -20 : 20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.3 }}
  >
    <div className="chat-message__avatar">
      {isBot ? <Bot size={20} /> : <User size={20} />}
    </div>
    <div className="chat-message__content">
      <div className="chat-message__text">
        {message.text.split('\n').map((line, i) => (
          <p key={i} dangerouslySetInnerHTML={{ 
            __html: line
              .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
              .replace(/•\s*(.+)/g, '<li>$1</li>')
          }} />
        ))}
      </div>
      
      {message.sources && message.sources.length > 0 && (
        <div className="chat-message__sources">
          <small>📚 المصادر:</small>
          {message.sources.slice(0, 3).map((source, i) => (
            <span key={i} className="source-tag">{source.title}</span>
          ))}
        </div>
      )}
      
      {message.suggestions && message.suggestions.length > 0 && (
        <div className="chat-message__suggestions">
          <Lightbulb size={14} />
          <span>اقتراحات:</span>
          {message.suggestions.map((suggestion, i) => (
            <button key={i} className="suggestion-btn">{suggestion}</button>
          ))}
        </div>
      )}
      
      <div className="chat-message__time">
        {new Date(message.timestamp).toLocaleTimeString('ar-EG', { 
          hour: '2-digit', 
          minute: '2-digit' 
        })}
      </div>
    </div>
  </motion.div>
);

const ChatInterface = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: 'مرحبًا بك! 👋 أنا مساعدك الذكي في مادة أمن المعلومات.\n\nيمكنني مساعدتك في:\n• الإجابة على أسئلتك عن محتوى الوحدات\n• شرح المفاهيم بشكل مبسط\n• إعطاء أمثلة عملية\n• إنشاء أسئلة اختبار\n\nكيف يمكنني مساعدتك اليوم؟',
      isBot: true,
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const bubbleRef = useRef(null);

  // ✅ Floating Animation - حركة عائمة مستمرة
  useEffect(() => {
    if (!isOpen && bubbleRef.current) {
      const interval = setInterval(() => {
        if (!isDragging) {
          setPosition({
            x: Math.random() * 20 - 10, // حركة عشوائية بسيطة
            y: Math.random() * 20 - 10
          });
        }
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [isOpen, isDragging]);

  // ✅ Scroll to bottom - بدون قفز
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ 
        behavior: 'smooth',
        block: 'end'
      });
    }
  };

  useEffect(() => {
    if (isOpen && !isMinimized) {
      setTimeout(() => {
        scrollToBottom();
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }, 300);
    }
  }, [messages, isOpen, isMinimized]);

  // ✅ منع الـ scroll عند الفتح
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      text: inputValue,
      isBot: false,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await askAssistant(inputValue);
      
      if (response.success) {
        const botMessage = {
          id: Date.now() + 1,
          text: response.data.answer,
          isBot: true,
          timestamp: new Date().toISOString(),
          sources: response.data.sources,
          suggestions: response.data.suggestions
        };
        setMessages(prev => [...prev, botMessage]);
      } else {
        const errorMessage = {
          id: Date.now() + 1,
          text: response.error || 'عذرًا، حدث خطأ. يرجى المحاولة مرة أخرى.',
          isBot: true,
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } catch (error) {
      console.error('Chat Error:', error);
      const errorMessage = {
        id: Date.now() + 1,
        text: 'عذرًا، واجهت مشكلة في الاتصال. يرجى المحاولة مرة أخرى.',
        isBot: true,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestion = (suggestion) => {
    setInputValue(suggestion);
    inputRef.current?.focus();
  };

  const quickQuestions = [
    'ما هو اختبار الاختراق؟',
    'اشرح HTTP ببساطة',
    'أعطني مثال على SQL Injection',
    'أنشئ لي اختبار'
  ];

  return (
    <>
      {/* ✅ الفقاعة العائمة المتحركة */}
      <motion.div
        ref={bubbleRef}
        className="chat-floating-bubble"
        onClick={() => setIsOpen(true)}
        animate={{
          x: position.x,
          y: position.y,
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          repeatType: "reverse"
        }}
        whileHover={{ scale: 1.1 }}
        style={{
          position: 'fixed',
          bottom: '2rem',
          left: '2rem',
          zIndex: 1000,
          cursor: 'pointer'
        }}
      >
        <div className="bubble-container">
          <div className="bubble-icon">
            <MessageCircle size={32} />
          </div>
          <div className="bubble-notification">
            <Sparkles size={12} />
          </div>
        </div>
        <div className="bubble-tooltip">
          اسألني عن أي شيء! 💡
        </div>
      </motion.div>

      {/* ✅ النافذة المنبثقة - Modal Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* خلفية مظللة */}
            <motion.div
              className="chat-modal-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
            />
            
            {/* النافذة المنبثقة */}
            <motion.div
              className="chat-modal-window"
              initial={{ 
                opacity: 0, 
                scale: 0.9,
                y: 50
              }}
              animate={{ 
                opacity: 1, 
                scale: 1,
                y: 0,
                minHeight: isMinimized ? 'auto' : '600px'
              }}
              exit={{ 
                opacity: 0, 
                scale: 0.9,
                y: 50
              }}
              transition={{ duration: 0.3 }}
              style={{
                position: 'fixed',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                zIndex: 1001,
                width: '90%',
                maxWidth: '600px',
                maxHeight: '80vh'
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="chat-modal-header">
                <div className="modal-header-info">
                  <div className="modal-header-icon">
                    <Bot size={24} />
                  </div>
                  <div>
                    <h3>المساعد الذكي التفاعلي</h3>
                    <p className="status-connected">
                      <span className="status-dot"></span>
                      متصل الآن
                    </p>
                  </div>
                </div>
                <div className="modal-header-actions">
                  <button
                    className="modal-btn"
                    onClick={() => setIsMinimized(!isMinimized)}
                    title={isMinimized ? 'تكبير' : 'تصغير'}
                  >
                    {isMinimized ? <Maximize2 size={18} /> : <Minimize2 size={18} />}
                  </button>
                  <button
                    className="modal-btn modal-btn-close"
                    onClick={() => setIsOpen(false)}
                    title="إغلاق"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>

              {/* Content */}
              {!isMinimized && (
                <>
                  {/* Messages */}
                  <div className="chat-modal-messages">
                    {messages.map(message => (
                      <ChatMessage
                        key={message.id}
                        message={message}
                        isBot={message.isBot}
                      />
                    ))}
                    
                    {isLoading && (
                      <motion.div
                        className="chat-message chat-message--bot"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      >
                        <div className="chat-message__avatar">
                          <Bot size={20} />
                        </div>
                        <div className="chat-message__content">
                          <div className="chat-loading">
                            <Loader size={16} className="loading-spinner" />
                            <span>جاري البحث في محتوى المقرر...</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Quick Questions */}
                  {messages.length <= 2 && (
                    <div className="chat-quick-questions">
                      <p className="quick-questions-title">💡 أسئلة سريعة:</p>
                      <div className="quick-questions-list">
                        {quickQuestions.map((q, i) => (
                          <button
                            key={i}
                            className="quick-question-btn"
                            onClick={() => handleSuggestion(q)}
                          >
                            {q}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Input */}
                  <div className="chat-input-container">
                    <textarea
                      ref={inputRef}
                      className="chat-input"
                      placeholder="اكتب سؤالك هنا..."
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyPress={handleKeyPress}
                      rows={2}
                      disabled={isLoading}
                    />
                    <button
                      className="chat-send-btn"
                      onClick={handleSend}
                      disabled={!inputValue.trim() || isLoading}
                      aria-label="إرسال"
                    >
                      <Send size={20} />
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatInterface;

import React, { useState, useCallback } from 'react';
import { 
  Book, Terminal, CheckCircle, Circle, ChevronLeft, ChevronRight 
} from 'lucide-react';
import PropTypes from 'prop-types';
import { motion, AnimatePresence } from 'framer-motion';
import './Sidebar.css';

const Sidebar = ({ 
  units, 
  progress, 
  onUnitSelect, 
  isCollapsed, 
  onToggleCollapse 
}) => {
  const [activeUnit, setActiveUnit] = useState(units[0]?.id || null);
  
  const handleUnitSelect = useCallback((unitId) => {
    setActiveUnit(unitId);
    onUnitSelect?.(unitId);
  }, [onUnitSelect]);
  
  const getUnitProgress = (unitId) => {
    return progress?.[unitId]?.percentage || 0;
  };
  
  const isUnitCompleted = (unitId) => {
    return progress?.[unitId]?.completed || false;
  };
  
  const sidebarVariants = {
    expanded: { width: '280px', transition: { duration: 0.3 } },
    collapsed: { width: '72px', transition: { duration: 0.3 } }
  };
  
  return (
    <motion.aside
      className={`sidebar ${isCollapsed ? 'sidebar--collapsed' : ''}`}
      variants={sidebarVariants}
      initial="expanded"
      animate={isCollapsed ? 'collapsed' : 'expanded'}
      role="navigation"
      aria-label="القائمة الجانبية للوحدات"
    >
      <button
        className="sidebar__toggle"
        onClick={onToggleCollapse}
        aria-label={isCollapsed ? 'فرد القائمة' : 'طي القائمة'}
      >
        {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
      </button>
      
      <AnimatePresence>
        {!isCollapsed && (
          <motion.div
            className="sidebar__header"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Book size={20} aria-hidden="true" />
            <span>الوحدات الدراسية</span>
          </motion.div>
        )}
      </AnimatePresence>
      
      <nav className="sidebar__nav" role="menubar">
        {units?.map((unit, index) => {
          const unitProgress = getUnitProgress(unit.id);
          const completed = isUnitCompleted(unit.id);
          const isActive = activeUnit === unit.id;
          
          return (
            <motion.button
              key={unit.id}
              className={`sidebar__item ${isActive ? 'sidebar__item--active' : ''} ${completed ? 'sidebar__item--completed' : ''}`}
              onClick={() => handleUnitSelect(unit.id)}
              role="menuitem"
              aria-current={isActive ? 'page' : undefined}
              whileHover={{ x: -4 }}
              whileTap={{ scale: 0.98 }}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <span className="sidebar__icon" aria-hidden="true">
                {completed ? (
                  <CheckCircle size={18} className="text-success" />
                ) : (
                  <Circle size={18} className="text-muted" />
                )}
              </span>
              
              <AnimatePresence>
                {!isCollapsed && (
                  <motion.div
                    className="sidebar__content"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <span className="sidebar__number">وحدة {unit.number}</span>
                    <span className="sidebar__title">{unit.title}</span>
                    
                    {!completed && unitProgress > 0 && (
                      <div className="sidebar__progress-mini">
                        <div 
                          className="sidebar__progress-fill" 
                          style={{ width: `${unitProgress}%` }}
                        />
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
              
              {isActive && (
                <motion.div
                  className="sidebar__indicator"
                  layoutId="activeIndicator"
                  aria-hidden="true"
                />
              )}
            </motion.button>
          );
        })}
      </nav>
      
      <AnimatePresence>
        {!isCollapsed && (
          <motion.div
            className="sidebar__lab-section"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Terminal size={16} aria-hidden="true" />
            <span>مختبر كالي لينكس</span>
            <span className="sidebar__lab-badge">عملي</span>
          </motion.div>
        )}
      </AnimatePresence>
      
      <div className="sidebar__footer">
        <AnimatePresence>
          {!isCollapsed && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              🔐 Engineered by Duha Twam
            </motion.span>
          )}
        </AnimatePresence>
      </div>
    </motion.aside>
  );
};

Sidebar.propTypes = {
  units: PropTypes.array.isRequired,
  progress: PropTypes.object,
  onUnitSelect: PropTypes.func,
  isCollapsed: PropTypes.bool,
  onToggleCollapse: PropTypes.func
};

Sidebar.defaultProps = {
  progress: {},
  onUnitSelect: () => {},
  isCollapsed: false,
  onToggleCollapse: () => {}
};

export default React.memo(Sidebar);
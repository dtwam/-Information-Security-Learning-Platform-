/**
 * 📄 CodeBlock.jsx
 * مكون عرض الأكواد مع تمييز الصيغة وزر النسخ
 * @module components/CodeBlock
 */

import React, { useState, useCallback } from 'react';
import { Copy, Check, Terminal } from 'lucide-react';
import PropTypes from 'prop-types';
import '../styles/unitContent.css';

/**
 * مكون عرض الكود مع ميزات النسخ والتمييز
 * @param {Object} props - خصائص المكون
 * @param {string} props.code - نص الكود للعرض
 * @param {string} props.language - لغة البرمجة (للعرض فقط)
 * @param {string} props.title - عنوان اختياري للكتلة
 * @param {boolean} props.showLineNumbers - إظهار أرقام الأسطر
 * @param {boolean} props.copyable - تفعيل زر النسخ
 */
const CodeBlock = ({ 
  code, 
  language = 'bash', 
  title, 
  showLineNumbers = true,
  copyable = true 
}) => {
  // ✅ حالة نسخ الكود
  const [copied, setCopied] = useState(false);
  
  /**
   * نسخ الكود إلى الحافظة
   * يستخدم Clipboard API مع معالجة الأخطاء
   */
  const handleCopy = useCallback(async () => {
    try {
      // ✅ التحقق من دعم Clipboard API
      if (!navigator.clipboard) {
        throw new Error('Clipboard API غير مدعوم في هذا المتصفح');
      }
      
      // ✅ نسخ النص
      await navigator.clipboard.writeText(code);
      
      // ✅ تحديث حالة النسخ
      setCopied(true);
      
      // ✅ إعادة الزر لحالته الأصلية بعد 2 ثانية
      const timer = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timer);
      
    } catch (error) {
      // ✅ معالجة الأخطاء بلطف
      console.error('❌ فشل نسخ الكود:', error);
      
      // ✅ محاولة بديلة باستخدام execCommand
      try {
        const textarea = document.createElement('textarea');
        textarea.value = code;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (fallbackError) {
        console.error('❌ فشلت الطريقة البديلة للنسخ:', fallbackError);
        // ✅ إظهار رسالة للمستخدم في واجهة حقيقية
      }
    }
  }, [code]);
  
  /**
   * تمييز بسيط للكود (Basic Syntax Highlighting)
   * ملاحظة: في مشروع حقيقي نستخدم Prism.js أو Highlight.js
   */
  const highlightCode = (codeStr, lang) => {
    // ✅ تقسيم الكود إلى أسطر
    const lines = codeStr.split('\n');
    
    return lines.map((line, index) => {
      let highlighted = line;
      
      // ✅ تمييز الكلمات المفتاحية حسب اللغة
      if (lang === 'bash' || lang === 'shell') {
        // تمييز الأوامر الشائعة
        highlighted = highlighted
          .replace(/^(sudo|apt|nmap|sqlmap|nikto|gobuster|curl|wget)/gm, '<span class="keyword">$1</span>')
          .replace(/(-[a-zA-Z]+|--[a-zA-Z-]+)/g, '<span class="string">$1</span>')
          .replace(/(['"]).*?\1/g, '<span class="string">$&</span>')
          .replace(/#.*$/gm, '<span class="comment">$&</span>');
      }
      
      if (lang === 'javascript' || lang === 'js') {
        highlighted = highlighted
          .replace(/\b(const|let|var|function|return|if|else|for|while|import|export|class|new)\b/g, '<span class="keyword">$1</span>')
          .replace(/(['"]).*?\1/g, '<span class="string">$&</span>')
          .replace(/\/\/.*$/gm, '<span class="comment">$&</span>')
          .replace(/\/\*[\s\S]*?\*\//g, '<span class="comment">$&</span>')
          .replace(/\b(\d+\.?\d*)\b/g, '<span class="number">$1</span>');
      }
      
      if (lang === 'python' || lang === 'py') {
        highlighted = highlighted
          .replace(/\b(def|class|if|else|elif|for|while|return|import|from|as|try|except|with|lambda)\b/g, '<span class="keyword">$1</span>')
          .replace(/(['"]).*?\1/g, '<span class="string">$&</span>')
          .replace(/#.*$/gm, '<span class="comment">$&</span>');
      }
      
      return (
        <span key={index} className="code-line">
          {showLineNumbers && (
            <span className="code-line-number" aria-hidden="true">
              {index + 1}
            </span>
          )}
          <span 
            className="code-line-content"
            dangerouslySetInnerHTML={{ __html: highlighted || ' ' }}
          />
        </span>
      );
    });
  };
  
  return (
    <figure className="code-block" role="region" aria-label={`كود ${language}`}>
      {/* ✅ رأس كتلة الكود */}
      {(title || copyable) && (
        <figcaption className="code-block__header">
          {title && (
            <div className="code-block__title">
              <Terminal size={14} aria-hidden="true" />
              <span>{title}</span>
              <span className="code-block__language">{language}</span>
            </div>
          )}
          
          {copyable && (
            <button
              className="code-block__copy-btn"
              onClick={handleCopy}
              aria-label={copied ? 'تم النسخ!' : 'نسخ الكود'}
              title={copied ? 'تم النسخ!' : 'نسخ الكود'}
              aria-live="polite"
            >
              {copied ? (
                <>
                  <Check size={16} className="text-success" aria-hidden="true" />
                  <span className="sr-only">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy size={16} aria-hidden="true" />
                  <span className="sr-only">نسخ</span>
                </>
              )}
            </button>
          )}
        </figcaption>
      )}
      
      {/* ✅ جسم كتلة الكود */}
      <pre className="code-block__body" tabIndex={0} aria-label="محتوى الكود">
        <code 
          className={`language-${language}`}
          dir="ltr"
          style={{ textAlign: 'left' }}
        >
          {highlightCode(code, language)}
        </code>
      </pre>
      
      {/* ✅ تذييل اختياري */}
      <div className="code-block__footer">
        <small className="text-muted">
          💡 اضغط على زر النسخ لحفظ هذا الكود
        </small>
      </div>
    </figure>
  );
};

// ✅ التحقق من أنواع الخصائص
CodeBlock.propTypes = {
  code: PropTypes.string.isRequired,
  language: PropTypes.string,
  title: PropTypes.string,
  showLineNumbers: PropTypes.bool,
  copyable: PropTypes.bool
};

CodeBlock.defaultProps = {
  language: 'bash',
  title: null,
  showLineNumbers: true,
  copyable: true
};

export default React.memo(CodeBlock);

import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types';
import './ThemeToggle.css';

const ThemeToggle = ({ isDarkMode, onToggle }) => {
  return (
    <motion.button
      className="theme-toggle"
      onClick={onToggle}
      aria-label={isDarkMode ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'}
      title={isDarkMode ? 'الوضع الفاتح' : 'الوضع الداكن'}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className="theme-toggle__container">
        <motion.div
          className="theme-toggle__icon"
          initial={false}
          animate={{
            rotate: isDarkMode ? 0 : 180,
            scale: isDarkMode ? 1 : 0
          }}
          transition={{ duration: 0.2 }}
        >
          <Moon size={20} />
        </motion.div>
        
        <motion.div
          className="theme-toggle__icon theme-toggle__icon--sun"
          initial={false}
          animate={{
            rotate: isDarkMode ? -180 : 0,
            scale: isDarkMode ? 0 : 1
          }}
          transition={{ duration: 0.2 }}
        >
          <Sun size={20} />
        </motion.div>
      </div>
      
      <span className="theme-toggle__label">
        {isDarkMode ? 'فاتح' : 'داكن'}
      </span>
    </motion.button>
  );
};

ThemeToggle.propTypes = {
  isDarkMode: PropTypes.bool.isRequired,
  onToggle: PropTypes.func.isRequired
};

export default React.memo(ThemeToggle);
/**
 * 📄 Header.jsx
 * المكون الرئيسي للرأس - يعرض شعار الجامعة وعنوان المنصة
 * @module components/Header
 */

import React from 'react';
import { Shield, Menu, Bell, User } from 'lucide-react';
import PropTypes from 'prop-types';
import './Header.css';

/**
 * مكون الهيدر الرئيسي
 * @param {Object} props - خصائص المكون
 * @param {Function} props.onToggleSidebar - دالة لفتح/إغلاق القائمة الجانبية
 * @param {Object} props.userInfo - معلومات المستخدم الحالي
 */
const Header = ({ onToggleSidebar, userInfo }) => {
  // ✅ معالجة الأخطاء المحتملة في عرض اسم المستخدم
  const userName = userInfo?.name || 'طالب';
  const userAvatar = userInfo?.avatar || null;
  
  return (
    <header 
      className="header" 
      role="banner"
      aria-label="رأس الصفحة الرئيسي"
    >
      {/* ✅ شريط التنقل العلوي */}
      <div className="header__container">
        
        {/* ✅ زر القائمة الجانبية - للجوال */}
        <button
          className="header__menu-btn"
          onClick={onToggleSidebar}
          aria-label="تبديل القائمة الجانبية"
          aria-expanded="false"
          title="القائمة"
        >
          <Menu size={24} aria-hidden="true" />
        </button>
        
        {/* ✅ شعار الجامعة وعنوان المادة */}
        <div className="header__brand">
          <img 
            src="https://upload.wikimedia.org/wikipedia/en/thumb/2/2c/Al-Quds_Open_University_logo.svg/1200px-Al-Quds_Open_University_logo.svg.png"
            alt="شعار جامعة القدس المفتوحة"
            className="header__logo"
            loading="lazy"
            width="40"
            height="40"
          />
          <div className="header__titles">
            <h1 className="header__university">جامعة القدس المفتوحة</h1>
            <p className="header__course">برمجيات وتطبيقات أمن المعلومات</p>
          </div>
        </div>
        
        {/* ✅ أدوات المستخدم */}
        <div className="header__actions">
          
          {/* ✅ زر الإشعارات */}
          <button 
            className="header__action-btn"
            aria-label="الإشعارات"
            title="الإشعارات"
          >
            <Bell size={20} aria-hidden="true" />
            <span className="header__badge" aria-label="3 إشعارات جديدة">3</span>
          </button>
          
          {/* ✅ قائمة المستخدم */}
          <div className="header__user">
            {userAvatar ? (
              <img 
                src={userAvatar} 
                alt={`صورة ${userName}`}
                className="header__avatar"
                width="36"
                height="36"
              />
            ) : (
              <div className="header__avatar-placeholder" aria-hidden="true">
                <User size={20} />
              </div>
            )}
            <span className="header__username" aria-live="polite">
              {userName}
            </span>
          </div>
          
        </div>
      </div>
      
      {/* ✅ شريط التقدم السريع */}
      <div className="header__progress-bar" role="progressbar" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100">
        <div className="header__progress-fill" style={{ width: '35%' }}>
          <span className="header__progress-text">35% مكتمل</span>
        </div>
      </div>
      
      {/* ✅ شارة الاعتماد */}
      <div className="header__credit" aria-label="تم التطوير بواسطة">
        <Shield size={14} aria-hidden="true" />
        <span>Engineered by Duha Twam</span>
      </div>
    </header>
  );
};

// ✅ التحقق من أنواع الخصائص (PropTypes)
Header.propTypes = {
  onToggleSidebar: PropTypes.func.isRequired,
  userInfo: PropTypes.shape({
    name: PropTypes.string,
    avatar: PropTypes.string
  })
};

// ✅ القيم الافتراضية
Header.defaultProps = {
  userInfo: {
    name: 'طالب',
    avatar: null
  }
};

export default React.memo(Header);
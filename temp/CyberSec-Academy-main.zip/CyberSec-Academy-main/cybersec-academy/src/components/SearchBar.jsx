
import React, { useState, useRef, useEffect } from 'react';
import { Search, X, Clock, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import PropTypes from 'prop-types';
import './SearchBar.css';

const SearchBar = ({ onSearch, suggestions = [] }) => {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);
  const inputRef = useRef(null);

  // ✅ Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  // ✅ Handle search submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch?.(query);
      addToRecent(query);
    }
  };

  // ✅ Add to recent searches
  const addToRecent = (search) => {
    const updated = [search, ...recentSearches.filter(s => s !== search)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
  };

  // ✅ Clear recent searches
  const clearRecent = () => {
    setRecentSearches([]);
    localStorage.removeItem('recentSearches');
  };

  // ✅ Handle suggestion click
  const handleSuggestionClick = (suggestion) => {
    setQuery(suggestion);
    onSearch?.(suggestion);
    addToRecent(suggestion);
    setIsFocused(false);
  };

  return (
    <div className={`search-bar ${isFocused ? 'search-bar--focused' : ''}`}>
      <form className="search-bar__form" onSubmit={handleSubmit}>
        <Search size={18} className="search-bar__icon" aria-hidden="true" />
        <input
          ref={inputRef}
          type="text"
          className="search-bar__input"
          placeholder="ابحث عن درس، وحدة، أو موضوع..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)}
          aria-label="بحث"
          aria-expanded={isFocused}
          aria-controls="search-suggestions"
        />
        {query && (
          <button
            type="button"
            className="search-bar__clear"
            onClick={() => setQuery('')}
            aria-label="مسح البحث"
          >
            <X size={14} />
          </button>
        )}
      </form>

      {/* ✅ Suggestions Dropdown */}
      <AnimatePresence>
        {isFocused && (query || recentSearches.length > 0) && (
          <motion.div
            id="search-suggestions"
            className="search-bar__suggestions"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            role="listbox"
          >
            {/* Recent Searches */}
            {recentSearches.length > 0 && !query && (
              <div className="search-bar__section">
                <div className="search-bar__section-header">
                  <Clock size={14} />
                  <span>عمليات بحث سابقة</span>
                  <button onClick={clearRecent} className="search-bar__clear-all">
                    مسح الكل
                  </button>
                </div>
                {recentSearches.map((search, index) => (
                  <button
                    key={index}
                    className="search-bar__suggestion"
                    onClick={() => handleSuggestionClick(search)}
                    role="option"
                  >
                    <Clock size={14} aria-hidden="true" />
                    <span>{search}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Trending Suggestions */}
            {suggestions.length > 0 && query && (
              <div className="search-bar__section">
                <div className="search-bar__section-header">
                  <TrendingUp size={14} />
                  <span>اقتراحات</span>
                </div>
                {suggestions
                  .filter(s => s.toLowerCase().includes(query.toLowerCase()))
                  .slice(0, 5)
                  .map((suggestion, index) => (
                    <button
                      key={index}
                      className="search-bar__suggestion"
                      onClick={() => handleSuggestionClick(suggestion)}
                      role="option"
                    >
                      <Search size={14} aria-hidden="true" />
                      <span>{suggestion}</span>
                    </button>
                  ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

SearchBar.propTypes = {
  onSearch: PropTypes.func,
  suggestions: PropTypes.arrayOf(PropTypes.string)
};

SearchBar.defaultProps = {
  onSearch: () => {},
  suggestions: []
};

export default React.memo(SearchBar);

import React from 'react';
import { BookOpen, Clock, CheckCircle, Play } from 'lucide-react';
import PropTypes from 'prop-types';
import { motion } from 'framer-motion';
import './UnitCard.css';

const UnitCard = ({ unit, progress = 0, completed = false, onClick }) => {
  const getStatusColor = () => {
    if (completed) return 'var(--accent-green)';
    if (progress > 0) return 'var(--accent-cyan)';
    return 'var(--text-muted)';
  };
  
  const getStatusText = () => {
    if (completed) return 'مكتملة ✓';
    if (progress > 0) return `${progress}% مكتمل`;
    return 'لم تبدأ';
  };
  
  const cardVariants = {
    hover: { 
      y: -8, 
      boxShadow: 'var(--shadow-lg), var(--glow-cyan)',
      transition: { duration: 0.2 }
    },
    tap: { scale: 0.98 }
  };
  
  return (
    <motion.article
      className="unit-card"
      role="article"
      onClick={onClick}
      onKeyDown={(e) => e.key === 'Enter' && onClick?.()}
      tabIndex={0}
      variants={cardVariants}
      whileHover="hover"
      whileTap="tap"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <header className="unit-card__header">
        <div className="unit-card__badge" style={{ backgroundColor: getStatusColor() }}>
          {completed ? <CheckCircle size={14} /> : <Clock size={14} />}
          <span>{getStatusText()}</span>
        </div>
        <span className="unit-card__number">وحدة {unit.number}</span>
      </header>
      
      <div className="unit-card__content">
        <BookOpen size={24} className="unit-card__icon" aria-hidden="true" />
        <h3 className="unit-card__title">{unit.title}</h3>
        <p className="unit-card__description">{unit.description}</p>
      </div>
      
      <div className="unit-card__progress">
        <div className="unit-card__progress-info">
          <span>التقدم</span>
          <span>{progress}%</span>
        </div>
        <div className="unit-card__progress-bar">
          <motion.div
            className="unit-card__progress-fill"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
            style={{ backgroundColor: getStatusColor() }}
          />
        </div>
      </div>
      
      <footer className="unit-card__footer">
        <button 
          className="unit-card__btn"
          onClick={(e) => {
            e.stopPropagation();
            onClick?.();
          }}
        >
          <Play size={16} aria-hidden="true" />
          <span>{completed ? 'مراجعة' : 'ابدأ الآن'}</span>
        </button>
      </footer>
      
      {progress === 0 && (
        <div className="unit-card__new-badge">جديد 🔥</div>
      )}
    </motion.article>
  );
};

UnitCard.propTypes = {
  unit: PropTypes.shape({
    id: PropTypes.string.isRequired,
    number: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired
  }).isRequired,
  progress: PropTypes.number,
  completed: PropTypes.bool,
  onClick: PropTypes.func
};

UnitCard.defaultProps = {
  progress: 0,
  completed: false,
  onClick: () => {}
};

export default React.memo(UnitCard);
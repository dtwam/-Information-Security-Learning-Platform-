/**
 * 📄 AchievementBadge.jsx
 * نظام شارات الإنجاز
 * @module components/AchievementBadge
 */

import React from 'react';
import { Trophy, Star, Zap, Shield, FileText, Terminal } from 'lucide-react';
import PropTypes from 'prop-types';
import { motion } from 'framer-motion';
import '../styles/dashboard.css';

/**
 * قائمة الشارات المتاحة
 */
const BADGES_CONFIG = {
  'first-scan': {
    id: 'first-scan',
    icon: <Terminal size={24} />,
    title: 'المسح الأول',
    description: 'أكمل وحدة الاستطلاع',
    requirement: 'إكمال الوحدة 2',
    color: 'var(--accent-cyan)',
    unlocked: false
  },
  'injection-master': {
    id: 'injection-master',
    icon: <Zap size={24} />,
    title: 'سيد الحقن',
    description: 'أتقن SQL Injection',
    requirement: 'إكمال الوحدة 5 بنسبة 100%',
    color: 'var(--accent-red)',
    unlocked: false
  },
  'proxy-pro': {
    id: 'proxy-pro',
    icon: <Shield size={24} />,
    title: 'محترف البروكسي',
    description: 'استخدم Burp في 10 تمارين',
    requirement: '10 استخدامات لمحاكي البروكسي',
    color: 'var(--accent-purple)',
    unlocked: false
  },
  'report-king': {
    id: 'report-king',
    icon: <FileText size={24} />,
    title: 'ملك التقارير',
    description: 'أنتج تقرير اختراق كامل',
    requirement: 'إكمال مشروع التخرج',
    color: 'var(--accent-yellow)',
    unlocked: false
  },
  'kali-ninja': {
    id: 'kali-ninja',
    icon: <Terminal size={24} />,
    title: 'نينجا كالي',
    description: 'استخدم 20 أمر مختلف',
    requirement: '20 أمر مختلف في المحاكي',
    color: 'var(--accent-green)',
    unlocked: false
  },
  'ethical-pro': {
    id: 'ethical-pro',
    icon: <Trophy size={24} />,
    title: 'محترف أخلاقي',
    description: 'أكمل الدورة مع الالتزام',
    requirement: 'إكمال جميع الوحدات + اختبار الأخلاقيات',
    color: 'var(--accent-cyan)',
    unlocked: false
  }
};

/**
 * مكون شارة الإنجاز
 * @param {Object} props - خصائص المكون
 * @param {string} props.badgeId - معرف الشارة
 * @param {Object} props.userData - بيانات تقدم المستخدم للشارات
 * @param {boolean} props.showDetails - إظهار التفاصيل عند التحويم
 */
const AchievementBadge = ({ badgeId, userData = {}, showDetails = true }) => {
  // ✅ جلب تكوين الشارة
  const config = BADGES_CONFIG[badgeId];
  if (!config) return null;
  
  // ✅ التحقق من حالة فتح الشارة
  const isUnlocked = userData?.[badgeId]?.unlocked || false;
  const progress = userData?.[badgeId]?.progress || 0;
  const maxProgress = userData?.[badgeId]?.maxProgress || 100;
  
  // ✅ متغيرات الأنيميشن
  const badgeVariants = {
    locked: { 
      filter: 'grayscale(100%) brightness(0.7)',
      scale: 1
    },
    unlocked: { 
      filter: 'grayscale(0%) brightness(1)',
      scale: [1, 1.05, 1],
      boxShadow: '0 0 20px rgba(0, 255, 157, 0.4)',
      transition: { duration: 0.3 }
    }
  };
  
  return (
    <motion.div
      className={`achievement-badge ${isUnlocked ? 'achievement-badge--unlocked' : 'achievement-badge--locked'}`}
      variants={badgeVariants}
      initial="locked"
      animate={isUnlocked ? 'unlocked' : 'locked'}
      whileHover={showDetails ? { y: -4, scale: 1.02 } : {}}
      role="img"
      aria-label={`${config.title}: ${isUnlocked ? 'مفتوحة ✓' : `مغلقة - ${progress}/${maxProgress}`}`}
      title={config.description}
    >
      {/* ✅ أيقونة الشارة */}
      <div 
        className="achievement-badge__icon"
        style={{ 
          color: isUnlocked ? config.color : 'var(--text-muted)',
          borderColor: isUnlocked ? config.color : 'var(--bg-tertiary)'
        }}
      >
        {config.icon}
        {isUnlocked && (
          <motion.div 
            className="achievement-badge__sparkle"
            initial={{ scale: 0 }}
            animate={{ scale: [0, 1.2, 1] }}
            transition={{ delay: 0.2 }}
          >
            <Star size={12} fill="var(--accent-yellow)" />
          </motion.div>
        )}
      </div>
      
      {/* ✅ معلومات الشارة */}
      <div className="achievement-badge__info">
        <h4 className="achievement-badge__title">{config.title}</h4>
        <p className="achievement-badge__desc">{config.description}</p>
        
        {/* ✅ شريط التقدم للشارات غير المفتوحة */}
        {!isUnlocked && progress > 0 && (
          <div className="achievement-badge__progress">
            <div 
              className="achievement-badge__progress-fill"
              style={{ 
                width: `${Math.min((progress / maxProgress) * 100, 100)}%`,
                backgroundColor: config.color
              }}
              role="progressbar"
              aria-valuenow={progress}
              aria-valuemin="0"
              aria-valuemax={maxProgress}
            />
            <span className="achievement-badge__progress-text">
              {progress}/{maxProgress}
            </span>
          </div>
        )}
        
        {/* ✅ متطلبات الشارة */}
        <small className="achievement-badge__requirement text-muted">
          {isUnlocked ? '✓ تم التحصيل' : `📋 ${config.requirement}`}
        </small>
      </div>
      
      {/* ✅ تأثير القفل للشارات المغلقة */}
      {!isUnlocked && (
        <div className="achievement-badge__lock" aria-hidden="true">
          🔒
        </div>
      )}
    </motion.div>
  );
};

/**
 * مكون مجموعة الشارات
 * @param {Object} props - خصائص المكون
 * @param {Object} props.userData - بيانات شارات المستخدم
 */
const AchievementBadgesGrid = ({ userData = {} }) => {
  return (
    <section className="achievement-badges" aria-labelledby="badges-title">
      <h3 id="badges-title" className="achievement-badges__title">
        <Trophy size={20} aria-hidden="true" />
        شارات الإنجاز
      </h3>
      
      <div className="achievement-badges__grid">
        {Object.keys(BADGES_CONFIG).map((badgeId, index) => (
          <motion.div
            key={badgeId}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <AchievementBadge 
              badgeId={badgeId} 
              userData={userData}
            />
          </motion.div>
        ))}
      </div>
    </section>
  );
};

// ✅ التحقق من أنواع الخصائص
AchievementBadge.propTypes = {
  badgeId: PropTypes.oneOf(Object.keys(BADGES_CONFIG)).isRequired,
  userData: PropTypes.object,
  showDetails: PropTypes.bool
};

AchievementBadgesGrid.propTypes = {
  userData: PropTypes.object
};

export { AchievementBadge, AchievementBadgesGrid };
export default AchievementBadge;
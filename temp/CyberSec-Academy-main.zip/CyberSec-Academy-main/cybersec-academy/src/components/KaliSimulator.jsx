/**
 * 📄 KaliSimulator.jsx
 * محاكي طرفية كالي لينكس آمن للتعليم
 * ⚠️ SAFE MODE: لا ينفذ أي أوامر حقيقية
 * @module components/KaliSimulator
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Terminal, X, Maximize2, Minimize2, Help } from 'lucide-react';
import PropTypes from 'prop-types';
import { motion, AnimatePresence } from 'framer-motion';
import '../styles/simulator.css';

/**
 * محاكي طرفية كالي لينكس التعليمي
 * @param {Object} props - خصائص المكون
 * @param {Function} props.onCommandExecuted - دالة عند تنفيذ أمر (لتتبع الإنجازات)
 * @param {boolean} props.isExpanded - حالة التكبير
 * @param {Function} props.onToggleExpand - دالة لتبديل حالة التكبير
 */
const KaliSimulator = ({ onCommandExecuted, isExpanded, onToggleExpand }) => {
  // ✅ حالات المكون
  const [history, setHistory] = useState([
    { type: 'system', content: '🔐 Kali Linux Educational Simulator v1.0' },
    { type: 'system', content: '⚠️ SAFE MODE: No real attacks executed' },
    { type: 'system', content: '📚 For educational purposes only - Al-Quds Open University' },
    { type: 'system', content: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━' },
    { type: 'system', content: 'اكتب "help" لعرض الأوامر المتاحة' },
  ]);
  const [input, setInput] = useState('');
  const [commandHistory, setCommandHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // ✅ مراجع للعناصر
  const terminalRef = useRef(null);
  const inputRef = useRef(null);
  
  // ✅ قائمة الأوامر المدعومة (محاكاة فقط)
  const AVAILABLE_COMMANDS = {
    help: {
      description: 'عرض هذه المساعدة',
      handler: () => `
📋 الأوامر المتاحة:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 reconnaissance:
  • nmap <target>     - مسح الشبكة (محاكاة)
  • whatweb <url>     - تحليل التقنية (محاكاة)
  • dnsrecon <domain> - استطلاع DNS (محاكاة)

⚔️ scanning:
  • nikto -h <url>    - مسح ثغرات الويب (محاكاة)
  • gobuster <url>    - اكتشاف المسارات (محاكاة)
  • sqlmap -u <url>   - اختبار SQL Injection (محاكاة)

🔧 utilities:
  • clear             - مسح الشاشة
  • history           - عرض سجل الأوامر
  • whoami            - عرض المستخدم الحالي
  • date              - عرض التاريخ والوقت

💡 نصائح:
  • اضغط Tab للإكمال التلقائي
  • اضغط ↑↓ للتنقل في السجل
  • جميع الأوامر في وضع آمن (SAFE MODE)
      `.trim()
    },
    nmap: {
      description: 'مسح الشبكة - Network Mapper (محاكاة)',
      handler: (args) => {
        const target = args[0] || 'target';
        return `
🔍 Starting Nmap simulation on ${target}...
[✓] Resolving hostname...
[✓] Scanning ports 1-1000...
[✓] Service detection...

PORT     STATE SERVICE     VERSION
22/tcp   open  ssh         OpenSSH 8.2
80/tcp   open  http        Apache 2.4.41
443/tcp  open  https       Apache 2.4.41
3306/tcp closed mysql

📊 Nmap done: 1 IP address scanned in 2.34 seconds
⚠️  هذه محاكاة تعليمية - لم يتم تنفيذ مسح حقيقي
        `.trim();
      }
    },
    nikto: {
      description: 'مسح ثغرات الويب - Nikto (محاكاة)',
      handler: (args) => {
        const url = args[args.indexOf('-h') + 1] || 'example.com';
        return `
🕷️  Starting Nikto simulation on ${url}...
+ Target: ${url}
+ Port: 80
+ Start Time: ${new Date().toLocaleTimeString('ar-EG')}

+ Server: Apache/2.4.41
+ Retrieved x-powered-by header: PHP/7.4.3

+ /admin/: Directory indexing found
+ /backup/: Potentially interesting directory
+ /wp-login.php: WordPress login page detected

+ ERROR: Error limit (20) reached for host
+ Scan terminated: 0 error(s) and 3 item(s) reported

⏱️  Run Time: 00:01:23
⚠️  هذه محاكاة تعليمية - لم يتم تنفيذ فحص حقيقي
        `.trim();
      }
    },
    sqlmap: {
      description: 'اختبار SQL Injection - Sqlmap (محاكاة)',
      handler: (args) => {
        const url = args[args.indexOf('-u') + 1] || 'http://example.com/page?id=1';
        return `
💉 Starting sqlmap simulation...
[INFO] target: ${url}
[INFO] testing connection to the target URL

[INFO] testing if the target URL content is stable
[INFO] target URL content is stable

[INFO] testing if GET parameter 'id' is dynamic
[INFO] GET parameter 'id' appears to be dynamic

[INFO] heuristic (basic) test shows that GET parameter 'id' might be injectable
[INFO] testing for SQL injection on GET parameter 'id'

[INFO] testing 'AND boolean-based blind'
[INFO] GET parameter 'id' appears to be 'AND boolean-based blind' injectable

Type: boolean-based blind
Title: AND boolean-based blind - WHERE or HAVING clause
Payload: id=1 AND 5849=5849

---
[INFO] the back-end DBMS is MySQL
[INFO] fetched data logged to text files

⚠️  هذه محاكاة تعليمية - لم يتم تنفيذ هجوم حقيقي
🔐 استخدم هذه المعرفة للدفاع وليس للهجوم
        `.trim();
      }
    },
    gobuster: {
      description: 'اكتشاف المسارات - Gobuster (محاكاة)',
      handler: (args) => {
        const url = args[0] || 'http://example.com';
        return `
🗂️  Starting Gobuster simulation...
================================================
Target URL: ${url}
Threads: 10
Wordlist: /usr/share/wordlists/dirb/common.txt
================================================

[+] Found: /admin (Status: 301)
[+] Found: /login (Status: 200)
[+] Found: /api (Status: 403)
[+] Found: /backup (Status: 404)
[+] Found: /config (Status: 403)
[+] Found: /images (Status: 301)
[+] Found: /js (Status: 301)
[+] Found: /css (Status: 301)

================================================
Finished: 2024-01-15 14:30:45
================================================
⚠️  هذه محاكاة تعليمية
        `.trim();
      }
    },
    whatweb: {
      description: 'تحليل تقنية الموقع - WhatWeb (محاكاة)',
      handler: (args) => {
        const target = args[0] || 'example.com';
        return `
🔎 WhatWeb simulation report for ${target}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[✓] HTTP Status: 200 OK
[✓] Title: Example Domain
[✓] IP Address: 93.184.216.34

📦 Technologies Detected:
  • Apache httpd 2.4.41
  • PHP 7.4.3
  • jQuery 3.6.0
  • Bootstrap 4.5.2
  • Google Analytics

🔐 Security Headers:
  • X-Frame-Options: SAMEORIGIN ✓
  • X-Content-Type-Options: nosniff ✓
  • Missing: Content-Security-Policy ⚠️

⚠️  هذه محاكاة تعليمية - تحليل غير فعلي
        `.trim();
      }
    },
    clear: {
      description: 'مسح شاشة الطرفية',
      handler: () => {
        setHistory([]);
        return null; // لا نعرض مخرجات
      }
    },
    history: {
      description: 'عرض سجل الأوامر',
      handler: () => {
        if (commandHistory.length === 0) {
          return '📭 لا توجد أوامر في السجل';
        }
        return commandHistory.map((cmd, idx) => `  ${idx + 1}  ${cmd}`).join('\n');
      }
    },
    whoami: {
      description: 'عرض المستخدم الحالي',
      handler: () => 'student@cybersec-academy (educational-mode)'
    },
    date: {
      description: 'عرض التاريخ والوقت',
      handler: () => new Date().toLocaleString('ar-EG', {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      })
    }
  };
  
  /**
   * معالجة تنفيذ الأمر
   * @param {string} cmd - الأمر المدخل
   */
  const executeCommand = useCallback((cmd) => {
    if (!cmd.trim()) return;
    
    // ✅ إضافة الأمر للسجل
    setHistory(prev => [...prev, { type: 'input', content: `student@kali:~$ ${cmd}` }]);
    setCommandHistory(prev => [...prev, cmd]);
    setHistoryIndex(-1);
    
    // ✅ تحليل الأمر
    const [command, ...args] = cmd.trim().split(/\s+/);
    const lowerCmd = command.toLowerCase();
    
    // ✅ التحقق من وجود المعالج
    if (AVAILABLE_COMMANDS[lowerCmd]) {
      setIsProcessing(true);
      
      // ✅ محاكاة وقت المعالجة
      setTimeout(() => {
        const result = AVAILABLE_COMMANDS[lowerCmd].handler(args);
        
        if (result !== null) {
          setHistory(prev => [...prev, { type: 'output', content: result }]);
        }
        
        // ✅ تتبع الاستخدام للإنجازات
        onCommandExecuted?.(lowerCmd);
        
        setIsProcessing(false);
        scrollToBottom();
      }, 500 + Math.random() * 1000);
      
    } else {
      // ✅ أمر غير معروف
      setHistory(prev => [...prev, { 
        type: 'error', 
        content: `❌ '${command}': command not found\n💡 اكتب 'help' لعرض الأوامر المتاحة` 
      }]);
      scrollToBottom();
    }
    
  }, [onCommandExecuted]);
  
  /**
   * معالجة إدخال المستخدم
   */
  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeCommand(input);
      setInput('');
    }
    
    // ✅ التنقل في سجل الأوامر
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = historyIndex < commandHistory.length - 1 ? historyIndex + 1 : historyIndex;
        setHistoryIndex(newIndex);
        setInput(commandHistory[commandHistory.length - 1 - newIndex] || '');
      }
    }
    
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setInput(commandHistory[commandHistory.length - 1 - newIndex] || '');
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInput('');
      }
    }
    
    // ✅ الإكمال التلقائي (Tab)
    if (e.key === 'Tab') {
      e.preventDefault();
      const partial = input.toLowerCase();
      const matches = Object.keys(AVAILABLE_COMMANDS).filter(cmd => 
        cmd.startsWith(partial)
      );
      
      if (matches.length === 1) {
        setInput(matches[0] + ' ');
      } else if (matches.length > 1) {
        setHistory(prev => [...prev, { 
          type: 'system', 
          content: `اقتراحات: ${matches.join('  ')}` 
        }]);
        scrollToBottom();
      }
    }
  }, [input, commandHistory, historyIndex, executeCommand]);
  
  /**
   * التمرير للأسفل عند إضافة محتوى جديد
   */
  const scrollToBottom = useCallback(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, []);
  
  // ✅ التركيز على حقل الإدخال عند التحميل
  useEffect(() => {
    inputRef.current?.focus();
  }, []);
  
  // ✅ التمرير التلقائي
  useEffect(() => {
    scrollToBottom();
  }, [history, scrollToBottom]);
  
  /**
   * التركيز على الطرفية عند النقر
   */
  const handleTerminalClick = useCallback(() => {
    inputRef.current?.focus();
  }, []);
  
  return (
    <motion.div 
      className={`kali-simulator ${isExpanded ? 'kali-simulator--expanded' : ''}`}
      role="application"
      aria-label="محاكي كالي لينكس التعليمي"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.2 }}
    >
      {/* ✅ رأس الطرفية */}
      <header className="kali-simulator__header">
        <div className="kali-simulator__title">
          <Terminal size={16} aria-hidden="true" />
          <span>Kali Linux Educational Terminal</span>
          <span className="kali-simulator__badge">SAFE MODE</span>
        </div>
        
        <div className="kali-simulator__controls">
          <button
            className="kali-simulator__control-btn"
            onClick={onToggleExpand}
            aria-label={isExpanded ? 'تصغير' : 'تكبير'}
            title={isExpanded ? 'تصغير' : 'تكبير'}
          >
            {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>
          <button
            className="kali-simulator__control-btn kali-simulator__control-btn--help"
            onClick={() => executeCommand('help')}
            aria-label="عرض المساعدة"
            title="المساعدة"
          >
            <Help size={14} />
          </button>
        </div>
      </header>
      
      {/* ✅ جسم الطرفية */}
      <main 
        ref={terminalRef}
        className="kali-simulator__body"
        onClick={handleTerminalClick}
        tabIndex={0}
        aria-live="polite"
      >
        <AnimatePresence>
          {history.map((item, index) => (
            <motion.div
              key={index}
              className={`kali-simulator__line kali-simulator__line--${item.type}`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.1 }}
            >
              {item.type === 'input' && (
                <span className="kali-simulator__prompt" aria-hidden="true">
                  student@kali:~$&nbsp;
                </span>
              )}
              <pre 
                className="kali-simulator__content"
                dangerouslySetInnerHTML={{ 
                  __html: item.content
                    .replace(/\n/g, '<br/>')
                    .replace(/\[✓\]/g, '<span class="text-success">[✓]</span>')
                    .replace(/\[INFO\]/g, '<span class="text-info">[INFO]</span>')
                    .replace(/⚠️/g, '<span class="text-warning">⚠️</span>')
                    .replace(/❌/g, '<span class="text-error">❌</span>')
                    .replace(/🔐|💉|🔍|🕷️|🗂️|🔎|📦|📋|💡|📊|⏱️/g, '<span class="emoji">$&</span>')
                }}
              />
            </motion.div>
          ))}
        </AnimatePresence>
        
        {/* ✅ مؤشر المعالجة */}
        {isProcessing && (
          <div className="kali-simulator__line kali-simulator__line--system">
            <span className="kali-simulator__cursor terminal-cursor">▊</span>
            <span className="text-muted">جاري المعالجة...</span>
          </div>
        )}
        
        {/* ✅ سطر الإدخال */}
        <div className="kali-simulator__input-line">
          <span className="kali-simulator__prompt" aria-hidden="true">
            student@kali:~$&nbsp;
          </span>
          <input
            ref={inputRef}
            type="text"
            className="kali-simulator__input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="اكتب أمرًا أو 'help' للمساعدة..."
            aria-label="حقل إدخال الأوامر"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck="false"
            disabled={isProcessing}
          />
          <span className="kali-simulator__cursor terminal-cursor" aria-hidden="true">▊</span>
        </div>
      </main>
      
      {/* ✅ تذييل الطرفية */}
      <footer className="kali-simulator__footer">
        <small className="text-muted">
          🔐 جميع الأوامر في وضع المحاكاة الآمنة | 
          اضغط Tab للإكمال التلقائي | ↑↓ للسجل
        </small>
      </footer>
      
      {/* ✅ شارة الاعتماد */}
      <div className="kali-simulator__credit">
        Engineered by Duha Twam
      </div>
    </motion.div>
  );
};

// ✅ التحقق من أنواع الخصائص
KaliSimulator.propTypes = {
  onCommandExecuted: PropTypes.func,
  isExpanded: PropTypes.bool,
  onToggleExpand: PropTypes.func
};

KaliSimulator.defaultProps = {
  onCommandExecuted: () => {},
  isExpanded: false,
  onToggleExpand: () => {}
};

export default React.memo(KaliSimulator);
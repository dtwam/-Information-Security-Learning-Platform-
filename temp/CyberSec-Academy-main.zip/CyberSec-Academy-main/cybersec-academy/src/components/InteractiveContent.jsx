/**
 * 📄 InteractiveContent.jsx
 * @module components/InteractiveContent
 */

import React, { useState, useCallback } from 'react';
import { 
  Lightbulb, AlertTriangle, Info, CheckCircle, XCircle, 
  ChevronDown, ChevronUp, Copy, ExternalLink 
} from 'lucide-react';
import PropTypes from 'prop-types';
import { motion, AnimatePresence } from 'framer-motion';
import '../styles/interactiveContent.css';

/**
 * مكون نصيحة/تحذير
 * @param {Object} props - خصائص المكون
 * @param {'tip'|'warning'|'info'|'danger'} props.type - نوع التنبيه
 * @param {string} props.title - العنوان
 * @param {string} props.children - المحتوى
 */
const AlertBox = ({ type = 'info', title, children }) => {
  const config = {
    tip: { icon: Lightbulb, class: 'alert-tip', label: '💡 نصيحة' },
    warning: { icon: AlertTriangle, class: 'alert-warning', label: '⚠️ تحذير' },
    info: { icon: Info, class: 'alert-info', label: 'ℹ️ معلومات' },
    danger: { icon: XCircle, class: 'alert-danger', label: '🚫 خطر' }
  };
  
  const { icon: Icon, class: cssClass, label } = config[type] || config.info;
  
  return (
    <motion.div
      className={`alert-box ${cssClass}`}
      role="alert"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.2 }}
    >
      <div className="alert-box__header">
        <Icon size={18} aria-hidden="true" />
        <strong>{title || label}</strong>
      </div>
      <div className="alert-box__content">
        {children}
      </div>
    </motion.div>
  );
};

/**
 * مكون خرافات وأحقاق (Mythbuster)
 */
const MythBuster = ({ myth, fact }) => {
  const [revealed, setRevealed] = useState(false);
  
  return (
    <motion.div 
      className="mythbuster"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <button
        className="mythbuster__trigger"
        onClick={() => setRevealed(!revealed)}
        aria-expanded={revealed}
        aria-controls="mythbuster-content"
      >
        <span className="mythbuster__myth">
          ❌ {myth}
        </span>
        <span className="mythbuster__toggle">
          {revealed ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </span>
      </button>
      
      <AnimatePresence>
        {revealed && (
          <motion.div
            id="mythbuster-content"
            className="mythbuster__fact"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
          >
            <CheckCircle size={18} className="text-success" aria-hidden="true" />
            <p>{fact}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

/**
 * مكون الجدول التفاعلي
 */
const InteractiveTable = ({ columns, data, sortable = true }) => {
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  
  /**
   * معالجة الفرز
   */
  const handleSort = useCallback((key) => {
    if (!sortable) return;
    
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  }, [sortable, sortConfig]);
  
  /**
   * بيانات مرتبة
   */
  const sortedData = React.useMemo(() => {
    if (!sortConfig.key) return data;
    
    return [...data].sort((a, b) => {
      const aVal = a[sortConfig.key];
      const bVal = b[sortConfig.key];
      
      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [data, sortConfig]);
  
  return (
    <div className="interactive-table" role="table" aria-label="جدول تفاعلي">
      <table>
        <thead>
          <tr>
            {columns.map((col) => (
              <th 
                key={col.key}
                onClick={() => handleSort(col.key)}
                className={sortable && col.sortable !== false ? 'interactive-table__sortable' : ''}
                aria-sort={sortConfig.key === col.key ? sortConfig.direction : 'none'}
              >
                {col.label}
                {sortable && col.sortable !== false && sortConfig.key === col.key && (
                  <span aria-hidden="true">
                    {sortConfig.direction === 'asc' ? ' ▲' : ' ▼'}
                  </span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row, index) => (
            <motion.tr
              key={row.id || index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ backgroundColor: 'var(--bg-hover)' }}
            >
              {columns.map((col) => (
                <td key={col.key} data-label={col.label}>
                  {col.render ? col.render(row[col.key], row) : row[col.key]}
                </td>
              ))}
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

/**
 * مكون المخطط الزمني (Timeline)
 */
const Timeline = ({ events }) => {
  return (
    <div className="timeline" role="list" aria-label="خط زمني للمراحل">
      {events.map((event, index) => (
        <motion.div
          key={event.id || index}
          className="timeline__item"
          role="listitem"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <div className="timeline__marker" aria-hidden="true">
            <div className="timeline__dot" style={{ backgroundColor: event.color || 'var(--accent-cyan)' }} />
            {index < events.length - 1 && <div className="timeline__line" />}
          </div>
          <div className="timeline__content">
            <time className="timeline__time" dateTime={event.date}>
              {event.time || event.date}
            </time>
            <h4 className="timeline__title">{event.title}</h4>
            <p className="timeline__desc">{event.description}</p>
            {event.details && (
              <details className="timeline__details">
                <summary>عرض التفاصيل</summary>
                <div className="timeline__details-content">
                  {event.details}
                </div>
              </details>
            )}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

/**
 * مكون محلل الترويسات (Header Analyzer)
 */
const HeaderAnalyzer = ({ headers }) => {
  const [analyzed, setAnalyzed] = useState(false);
  
  const analyzeHeaders = useCallback(() => {
    setAnalyzed(true);
  }, []);
  
  const getSecurityStatus = (headerName) => {
    const securityHeaders = [
      'Content-Security-Policy',
      'X-Frame-Options',
      'X-Content-Type-Options',
      'Strict-Transport-Security',
      'Referrer-Policy'
    ];
    return securityHeaders.includes(headerName) ? 'secure' : 'info';
  };
  
  return (
    <div className="header-analyzer">
      {!analyzed ? (
        <div className="header-analyzer__prompt">
          <Info size={24} aria-hidden="true" />
          <p>اضغط لتحليل ترويسات الأمان</p>
          <button className="btn" onClick={analyzeHeaders}>
            بدء التحليل
          </button>
        </div>
      ) : (
        <div className="header-analyzer__results">
          <h4>نتائج تحليل الترويسات</h4>
          <ul className="header-analyzer__list">
            {Object.entries(headers).map(([key, value]) => {
              const status = getSecurityStatus(key);
              return (
                <li key={key} className={`header-analyzer__item header-analyzer__item--${status}`}>
                  <span className="header-analyzer__name">{key}</span>
                  <code className="header-analyzer__value">{value}</code>
                  {status === 'secure' && (
                    <CheckCircle size={16} className="text-success" aria-label="آمن" />
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};

/**
 * المكون الرئيسي للمحتوى التفاعلي
 * يجمع جميع المكونات الفرعية
 */
const InteractiveContent = ({ type, props }) => {
  const components = {
    alert: AlertBox,
    mythbuster: MythBuster,
    table: InteractiveTable,
    timeline: Timeline,
    headerAnalyzer: HeaderAnalyzer
  };
  
  const Component = components[type];
  
  if (!Component) {
    console.warn(`⚠️ مكون غير معروف: ${type}`);
    return <div className="text-muted">محتوى غير متاح</div>;
  }
  
  return <Component {...props} />;
};

// ✅ التحقق من أنواع الخصائص
AlertBox.propTypes = {
  type: PropTypes.oneOf(['tip', 'warning', 'info', 'danger']),
  title: PropTypes.string,
  children: PropTypes.node.isRequired
};

MythBuster.propTypes = {
  myth: PropTypes.string.isRequired,
  fact: PropTypes.string.isRequired
};

InteractiveTable.propTypes = {
  columns: PropTypes.arrayOf(PropTypes.shape({
    key: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    sortable: PropTypes.bool,
    render: PropTypes.func
  })).isRequired,
  data: PropTypes.array.isRequired,
  sortable: PropTypes.bool
};

Timeline.propTypes = {
  events: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    date: PropTypes.string,
    time: PropTypes.string,
    title: PropTypes.string.isRequired,
    description: PropTypes.string,
    details: PropTypes.node,
    color: PropTypes.string
  })).isRequired
};

HeaderAnalyzer.propTypes = {
  headers: PropTypes.object.isRequired
};

InteractiveContent.propTypes = {
  type: PropTypes.oneOf(['alert', 'mythbuster', 'table', 'timeline', 'headerAnalyzer']).isRequired,
  props: PropTypes.object.isRequired
};

export default InteractiveContent;
export { AlertBox, MythBuster, InteractiveTable, Timeline, HeaderAnalyzer };
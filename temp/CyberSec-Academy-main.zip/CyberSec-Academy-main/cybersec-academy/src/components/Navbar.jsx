

import React, { useState, useEffect } from 'react';
import { 
  Menu, X, Search, Moon, Sun, Book, 
  ChevronDown, Bell, User, Home 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import PropTypes from 'prop-types';
import './Navbar.css';

const Navbar = ({ 
  onSearch, 
  onToggleTheme, 
  isDarkMode,
  userInfo 
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // ✅ Detect scroll for navbar styling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // ✅ Handle search submission
  const handleSearch = (e) => {
    e.preventDefault();
    onSearch?.(searchQuery);
  };

  // ✅ Close menu on escape key
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') setIsMenuOpen(false);
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, []);

  // ✅ Prevent body scroll when menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  const navLinks = [
    { name: 'الرئيسية', icon: Home, href: '#home' },
    { name: 'الوحدات', icon: Book, href: '#units' },
    { name: 'التقدم', icon: ChevronDown, href: '#progress' },
  ];

  return (
    <>
      <motion.nav
        className={`navbar ${isScrolled ? 'navbar--scrolled' : ''} ${isMenuOpen ? 'navbar--menu-open' : ''}`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.3 }}
        role="navigation"
        aria-label="الشريط الرئيسي"
      >
        <div className="navbar__container">
          
          {/* ✅ Logo & Brand */}
          <div className="navbar__brand">
            <img 
              src="/logo.png" 
              alt="شعار جامعة القدس المفتوحة"
              className="navbar__logo"
              width="40"
              height="40"
              loading="lazy"
            />
            <div className="navbar__titles">
              <h1 className="navbar__university">جامعة القدس المفتوحة</h1>
              <span className="navbar__course">أمن المعلومات</span>
            </div>
          </div>

          {/* ✅ Desktop Navigation */}
          <div className="navbar__desktop">
            <ul className="navbar__links">
              {navLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href}
                    className="navbar__link"
                  >
                    <link.icon size={18} aria-hidden="true" />
                    <span>{link.name}</span>
                  </a>
                </li>
              ))}
            </ul>

            {/* ✅ Search Bar */}
            <form className={`navbar__search ${isSearchFocused ? 'navbar__search--focused' : ''}`} onSubmit={handleSearch}>
              <Search size={18} className="navbar__search-icon" aria-hidden="true" />
              <input
                type="text"
                className="navbar__search-input"
                placeholder="ابحث عن درس..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
                aria-label="بحث عن الدروس"
              />
              {searchQuery && (
                <button 
                  type="button"
                  className="navbar__search-clear"
                  onClick={() => setSearchQuery('')}
                  aria-label="مسح البحث"
                >
                  <X size={14} />
                </button>
              )}
            </form>

            {/* ✅ Actions */}
            <div className="navbar__actions">
              {/* Theme Toggle */}
              <button
                className="navbar__action-btn navbar__theme-toggle"
                onClick={onToggleTheme}
                aria-label={isDarkMode ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'}
                title={isDarkMode ? 'الوضع الفاتح' : 'الوضع الداكن'}
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>

              {/* Notifications */}
              <button
                className="navbar__action-btn"
                aria-label="الإشعارات"
                title="الإشعارات"
              >
                <Bell size={20} />
                <span className="navbar__badge">3</span>
              </button>

              {/* User Menu */}
              <div className="navbar__user">
                <div className="navbar__avatar">
                  {userInfo?.avatar ? (
                    <img src={userInfo.avatar} alt={userInfo.name} />
                  ) : (
                    <User size={20} />
                  )}
                </div>
                <span className="navbar__username">{userInfo?.name || 'طالب'}</span>
                <ChevronDown size={16} aria-hidden="true" />
              </div>
            </div>
          </div>

          {/* ✅ Mobile Menu Button */}
          <button
            className="navbar__menu-btn"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
          >
            <AnimatePresence mode="wait">
              {isMenuOpen ? (
                <motion.span
                  key="close"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                >
                  <X size={24} />
                </motion.span>
              ) : (
                <motion.span
                  key="menu"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                >
                  <Menu size={24} />
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>

        {/* ✅ Mobile Search Bar */}
        <div className="navbar__mobile-search">
          <form onSubmit={handleSearch}>
            <Search size={18} aria-hidden="true" />
            <input
              type="text"
              placeholder="ابحث عن درس..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              aria-label="بحث عن الدروس"
            />
          </form>
        </div>
      </motion.nav>

      {/* ✅ Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              className="navbar__overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              aria-hidden="true"
            />
            
            <motion.div
              id="mobile-menu"
              className="navbar__mobile-menu"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25 }}
              role="dialog"
              aria-modal="true"
              aria-label="قائمة التنقل"
            >
              <div className="navbar__mobile-header">
                <div className="navbar__brand">
                  <img src="/logo.png" alt="الشعار" width="32" height="32" />
                  <span>جامعة القدس المفتوحة</span>
                </div>
              </div>

              <ul className="navbar__mobile-links">
                {navLinks.map((link, index) => (
                  <motion.li
                    key={link.name}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <a href={link.href} className="navbar__mobile-link">
                      <link.icon size={20} aria-hidden="true" />
                      <span>{link.name}</span>
                    </a>
                  </motion.li>
                ))}
              </ul>

              <div className="navbar__mobile-actions">
                <button
                  className="navbar__mobile-action"
                  onClick={onToggleTheme}
                >
                  {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
                  <span>{isDarkMode ? 'الوضع الفاتح' : 'الوضع الداكن'}</span>
                </button>
                
                <div className="navbar__mobile-user">
                  <div className="navbar__avatar">
                    <User size={20} />
                  </div>
                  <span>{userInfo?.name || 'طالب'}</span>
                </div>
              </div>

              <div className="navbar__mobile-footer">
                <small>🔐 Engineered by Duha Twam</small>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

Navbar.propTypes = {
  onSearch: PropTypes.func,
  onToggleTheme: PropTypes.func,
  isDarkMode: PropTypes.bool,
  userInfo: PropTypes.shape({
    name: PropTypes.string,
    avatar: PropTypes.string
  })
};

Navbar.defaultProps = {
  onSearch: () => {},
  onToggleTheme: () => {},
  isDarkMode: true,
  userInfo: { name: 'طالب', avatar: null }
};

export default React.memo(Navbar);
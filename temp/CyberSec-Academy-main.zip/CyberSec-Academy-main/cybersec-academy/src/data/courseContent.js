/**
 * 📄 courseContent.js
 * المحتوى التعليمي الكامل للوحدات السبع
 * برمجيات وتطبيقات أمن المعلومات 1272
 * جامعة القدس المفتوحة
 * 🔐 Engineered by Duha Twam
 */

// ✅ نظرة عامة على المادة
export const courseOverview = {
  id: 'security-software',
  title: 'برمجيات وتطبيقات أمن المعلومات',
  university: 'جامعة القدس المفتوحة',
  program: 'أنظمة المعلومات والتطبيقات الحاسوبية / أمن معلومات',
  instructor: 'المهندس: Duha Twam',
  description: 'هذه المادة لا تركز فقط على "الاختراق"، بل على فهم كيفية بناء تطبيقات الويب بطريقة آمنة، وفهم آلية استغلالها لاكتشاف نقاط الضعف.',
  philosophy: 'لفهم الحماية يجب فهم الهجوم.',
  estimatedHours: 45,
  totalUnits: 7,
  difficulty: 'متوسط - متقدم'
};

// ✅ الوحدات الدراسية السبع
export const units = [
  // =====================================================
  // الوحدة 1: أساسيات اختبار اختراق الويب
  // =====================================================
  {
    id: 'unit-1',
    number: 1,
    title: 'أساسيات اختبار اختراق الويب',
    titleEn: 'Penetration Testing Fundamentals',
    description: 'مقدمة شاملة في مفاهيم اختبار الاختراق وأنواع التطبيقات ومبادئ الأمن السيبراني',
    estimatedTime: 90,
    objectives: [
      'فهم عمل سيرفرات الويب (IIS, Apache)',
      'شرح بروتوكول HTTP/HTTPS وآلية العمل',
      'تحليل ترويسات الطلب والاستجابة',
      'رسم دورة حياة Request/Response',
      'تطبيق مراحل اختبار الاختراق الأربع'
    ],
    
    sections: [
      {
        title: 'مقدمة الوحدة',
        type: 'intro',
        content: `
## فلسفة المادة

هذه المادة لا تركز فقط على الاختراق، بل على فهم كيفية بناء تطبيقات الويب بطريقة آمنة، وفهم آلية استغلالها لاكتشاف نقاط الضعف.

**المبدأ الأساسي:** لفهم الحماية يجب فهم الهجوم.
        `
      },
      
      {
        title: 'سيرفرات الويب',
        type: 'concept',
        content: `
## ما هو سيرفر الويب؟

**سيرفر الويب** هو برنامج يعمل داخل نظام تشغيل الخادم (Server OS). وظيفته استقبال طلبات HTTP/HTTPS من المتصفح ثم إعادة الملفات المناسبة.

### الأنواع الرئيسية

| النوع | نظام التشغيل | الملاحظات |
|-------|-------------|-----------|
| **IIS** | Windows Server | طريقة الإعداد قد تؤدي لثغرات |
| **Apache** | Linux | الأكثر استخدامًا عالميًا |

### مثال توضيحي: كيف يعمل الويب؟

عندما تكتب www.example.com:

1. المتصفح يرسل طلب HTTP
2. السيرفر (مثلاً Apache) يستقبل الطلب
3. يبحث عن الملف المطلوب
4. يعيده للمتصفح
        `,
        diagram: {
          type: 'client-server',
          svg: `
<svg viewBox="0 0 800 300" xmlns="http://www.w3.org/2000/svg">
  <rect x="50" y="100" width="120" height="80" rx="10" fill="#0ea5e9" opacity="0.2" stroke="#0ea5e9" stroke-width="2"/>
  <text x="110" y="135" text-anchor="middle" fill="#0ea5e9" font-size="14" font-weight="bold">المتصفح</text>
  <text x="110" y="155" text-anchor="middle" fill="#94a3b8" font-size="11">Client</text>
  <line x1="170" y1="140" x2="280" y2="140" stroke="#06b6d4" stroke-width="3" marker-end="url(#arrowhead)"/>
  <text x="225" y="130" text-anchor="middle" fill="#06b6d4" font-size="12">HTTP Request</text>
  <rect x="300" y="80" width="150" height="120" rx="10" fill="#8b5cf6" opacity="0.2" stroke="#8b5cf6" stroke-width="2"/>
  <text x="375" y="130" text-anchor="middle" fill="#8b5cf6" font-size="14" font-weight="bold">Web Server</text>
  <text x="375" y="155" text-anchor="middle" fill="#94a3b8" font-size="11">Apache/IIS</text>
  <line x1="450" y1="140" x2="560" y2="140" stroke="#10b981" stroke-width="3" marker-end="url(#arrowhead2)"/>
  <text x="505" y="130" text-anchor="middle" fill="#10b981" font-size="12">HTTP Response</text>
  <rect x="580" y="100" width="120" height="80" rx="10" fill="#10b981" opacity="0.2" stroke="#10b981" stroke-width="2"/>
  <text x="640" y="135" text-anchor="middle" fill="#10b981" font-size="14" font-weight="bold">الصفحة</text>
  <text x="640" y="155" text-anchor="middle" fill="#94a3b8" font-size="11">HTML</text>
  <defs>
    <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
      <polygon points="0 0, 10 3, 0 6" fill="#06b6d4"/>
    </marker>
    <marker id="arrowhead2" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
      <polygon points="0 0, 10 3, 0 6" fill="#10b981"/>
    </marker>
  </defs>
</svg>`
        }
      },
      
      {
        title: 'تطبيقات الويب',
        type: 'concept',
        content: `
## ما هو تطبيق الويب؟

تطبيق الويب هو **منطق البرمجة** الذي يعمل على السيرفر ويؤمن التفاعل مع المستخدم.

### وظائف تطبيق الويب:
- يعالج إدخال المستخدم
- يتواصل مع قاعدة البيانات
- يحدد الصلاحيات
- يولد الاستجابة

### لماذا هو هدف للاختراق؟
لأنه يحتوي على:
- **مدخلات** من المستخدم
- **منطق برمجي** للمعالجة
- **اتصال بقاعدة بيانات**

كل هذه نقاط قابلة للاستغلال إذا لم يتم تأمينها.
        `
      },
      
      {
        title: 'بروتوكول HTTP',
        type: 'concept',
        content: `
## HTTP (Hypertext Transfer Protocol)

**HTTP** هو بروتوكول متفق عليه للتفاعل مع تطبيق الويب.

### خاصية مهمة: Stateless
HTTP هو بروتوكول **عديم الحالة** - أي أنه لا يتذكر الطلبات السابقة.
**بدون Cookies لا يوجد اعتبار للجلسة.**

### مثال:
لو سجلت دخولك:
- **طلب 1:** تسجيل دخول
- **طلب 2:** عرض الصفحة

السيرفر لا يعرف أنك نفس الشخص إلا إذا استخدمنا Cookies.
        `
      },
      
      {
        title: 'دورة حياة HTTP',
        type: 'diagram-section',
        content: `
## كيف يعمل HTTP Request/Response؟

### الطلب (Request)
المتصفح يرسل Request يحتوي:
- **Method:** GET أو POST
- **Headers:** معلومات إضافية
- **Body:** البيانات (في POST)

### الاستجابة (Response)
السيرفر يرسل Response يحتوي:
- **Status Code:** 200 أو 404 أو 500
- **Headers:** معلومات عن الاستجابة
- **Content:** المحتوى المطلوب
        `,
        diagram: {
          type: 'http-lifecycle',
          svg: `
<svg viewBox="0 0 900 400" xmlns="http://www.w3.org/2000/svg">
  <rect x="50" y="50" width="350" height="130" rx="10" fill="#0ea5e9" opacity="0.15" stroke="#0ea5e9" stroke-width="2"/>
  <text x="225" y="80" text-anchor="middle" fill="#0ea5e9" font-size="16" font-weight="bold">HTTP Request</text>
  <text x="70" y="110" fill="#94a3b8" font-size="12">• Method: GET / POST</text>
  <text x="70" y="130" fill="#94a3b8" font-size="12">• Headers (User-Agent, Cookie, Host)</text>
  <text x="70" y="150" fill="#94a3b8" font-size="12">• Body (في حالة POST)</text>
  <line x1="400" y1="115" x2="500" y2="115" stroke="#06b6d4" stroke-width="3" marker-end="url(#arrow1)"/>
  <text x="450" y="105" text-anchor="middle" fill="#06b6d4" font-size="12">إرسال الطلب</text>
  <rect x="500" y="50" width="150" height="130" rx="10" fill="#8b5cf6" opacity="0.15" stroke="#8b5cf6" stroke-width="2"/>
  <text x="575" y="120" text-anchor="middle" fill="#8b5cf6" font-size="14" font-weight="bold">السيرفر</text>
  <line x1="650" y1="115" x2="750" y2="115" stroke="#10b981" stroke-width="3" marker-end="url(#arrow2)"/>
  <text x="700" y="105" text-anchor="middle" fill="#10b981" font-size="12">الاستجابة</text>
  <rect x="750" y="50" width="130" height="130" rx="10" fill="#10b981" opacity="0.15" stroke="#10b981" stroke-width="2"/>
  <text x="815" y="90" text-anchor="middle" fill="#10b981" font-size="14" font-weight="bold">Response</text>
  <text x="815" y="115" text-anchor="middle" fill="#94a3b8" font-size="11">Status Code</text>
  <text x="815" y="135" text-anchor="middle" fill="#94a3b8" font-size="11">Content</text>
  <rect x="50" y="220" width="800" height="160" rx="10" fill="#1e293b" stroke="#334155" stroke-width="2"/>
  <text x="450" y="250" text-anchor="middle" fill="#f1f5f9" font-size="14" font-weight="bold">رموز الحالة الشائعة</text>
  <text x="100" y="290" fill="#10b981" font-size="13" font-weight="bold">200 OK</text>
  <text x="100" y="310" fill="#94a3b8" font-size="11">طلب ناجح</text>
  <text x="300" y="290" fill="#f59e0b" font-size="13" font-weight="bold">404 Not Found</text>
  <text x="300" y="310" fill="#94a3b8" font-size="11">الصفحة غير موجودة</text>
  <text x="550" y="290" fill="#ef4444" font-size="13" font-weight="bold">500 Error</text>
  <text x="550" y="310" fill="#94a3b8" font-size="11">خطأ في السيرفر</text>
  <text x="750" y="290" fill="#0ea5e9" font-size="13" font-weight="bold">301 Redirect</text>
  <text x="750" y="310" fill="#94a3b8" font-size="11">إعادة توجيه</text>
  <defs>
    <marker id="arrow1" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
      <polygon points="0 0, 10 3, 0 6" fill="#06b6d4"/>
    </marker>
    <marker id="arrow2" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
      <polygon points="0 0, 10 3, 0 6" fill="#10b981"/>
    </marker>
  </defs>
</svg>`
        }
      },
      
      {
        title: 'الترويسات (Headers)',
        type: 'concept',
        content: `
## Request Headers (ترويسات الطلب)
- **User-Agent:** معلومات عن المتصفح
- **Cookie:** بيانات الجلسة
- **Host:** اسم السيرفر

## Response Headers (ترويسات الاستجابة)
- **Set-Cookie:** تعيين الكوكيز
- **Server:** نوع السيرفر
- **Content-Type:** نوع المحتوى

### أهمية أمنية
**الترويسات قد تكشف:**
- نوع السيرفر
- إصدار النظام
- سياسات الحماية

وهذا يساعد في مرحلة الاستطلاع لاحقًا.
        `,
        infoBox: {
          type: 'warning',
          title: 'معلومة مهمة',
          content: 'الترويسات قد تسرب معلومات حساسة عن النظام. يجب إخفاء أو تعديل الترويسات الحساسة في بيئة الإنتاج.'
        }
      },
      
      {
        title: 'HTTPS والأمان',
        type: 'concept',
        content: `
## HTTPS = HTTP + SSL/TLS

### وظيفة HTTPS:
- **تشفير البيانات** أثناء النقل
- **منع التنصت** على الاتصال
- **منع التعديل** أثناء الإرسال

### تحذير مهم
**HTTPS لا يمنع SQL Injection أو XSS**
هو فقط يحمي النقل وليس منطق التطبيق.
        `,
        infoBox: {
          type: 'danger',
          title: 'تحذير أمني',
          content: 'كثير من المطورين يظنون أن HTTPS يكفي للحماية. هذا خطأ! HTTPS يحمي الاتصال فقط، لكن ثغرات التطبيق مثل SQL Injection و XSS تبقى موجودة.'
        }
      },
      
      {
        title: 'مراحل اختبار الاختراق',
        type: 'timeline',
        items: [
          { phase: '1', title: 'Reconnaissance (الاستطلاع)', desc: 'جمع معلومات عن الهدف: IP، DNS، نظام التشغيل، خدمات مفتوحة. هذه ستفصل في الوحدة الثانية.' },
          { phase: '2', title: 'Scanning (المسح)', desc: 'فحص البورتات، اكتشاف الثغرات، تحليل الخدمات. تفصيل في الوحدة الثالثة والرابعة.' },
          { phase: '3', title: 'Exploitation (الاستغلال)', desc: 'استخدام الثغرة للحصول على: تنفيذ أوامر، رفع شيل، سرقة بيانات. تفصيل في الوحدة الثالثة والخامسة.' },
          { phase: '4', title: 'Maintain Access', desc: 'المحافظة على الوصول عبر: زرع Backdoor، تثبيت Web Shell، إنشاء مستخدم مخفي. ربط مع Metasploit لاحقًا.' }
        ]
      },
      
      {
        title: 'ثغرات الويب الشائعة',
        type: 'concept',
        content: `
## الثغرات الأكثر شيوعًا
- **SQL Injection:** حقن أوامر SQL
- **XSS:** Cross-Site Scripting
- **CSRF:** Cross-Site Request Forgery
- **Authentication Bypass:** كسر المصادقة

### أين ستتعلمها؟
- **الوحدة الخامسة:** ثغرات الحقن (Injection)
- **الوحدة السابعة:** هجمات جانب العميل (XSS, CSRF)
        `
      },
      
      {
        title: 'كالي لينكس Kali Linux',
        type: 'concept',
        content: `
## ما هو Kali Linux؟
**كالي ليس أداة اختراق بحد ذاته.** هو بيئة تحتوي على أدوات اختبار الاختراق.

### المميزات:
- أُعلن عنه 2013
- مبني على Debian
- أكثر من 300 أداة
- يدعم حقن حزم الشبكات اللاسلكية
- مفتوح المصدر
- مستودعات محدثة
- بيئة عمل احترافية
        `,
        tools: [
          { name: 'Nmap', desc: 'فحص البورتات واكتشاف الخدمات' },
          { name: 'Nessus/Nikto', desc: 'فحص ثغرات الويب' },
          { name: 'Burp Suite/ZAP', desc: 'اعتراض وتحليل طلبات HTTP' },
          { name: 'Sqlmap', desc: 'استغلال ثغرات SQL Injection' },
          { name: 'Metasploit', desc: 'إطار عمل الاستغلال المتقدم' },
          { name: 'SET', desc: 'أدوات الهندسة الاجتماعية' }
        ]
      }
    ],
    
    quiz: [
      { question: 'ما هو البروتوكول المستخدم لنقل صفحات الويب؟', options: ['FTP', 'HTTP', 'SMTP', 'SSH'], correct: 1, explanation: 'HTTP هو البروتوكول الأساسي لنقل صفحات الويب' },
      { question: 'أي من التالي ليس من مراحل اختبار الاختراق؟', options: ['الاستطلاع', 'المسح', 'الاستغلال', 'التشفير'], correct: 3, explanation: 'التشفير ليس مرحلة من مراحل الاختراق، بل هو وسيلة حماية' },
      { question: 'لماذا HTTPS لا يمنع SQL Injection؟', options: ['لأنه بطيء', 'لأنه يحمي النقل فقط وليس التطبيق', 'لأنه قديم', 'لا سبب'], correct: 1, explanation: 'HTTPS يحمي البيانات أثناء النقل فقط، لكن لا يحمي منطق التطبيق من الثغرات' }
    ],
    
    summary: [
      'فهم البنية الأساسية لتطبيقات الويب (Client-Server)',
      'معرفة عمل بروتوكول HTTP/HTTPS والترويسات',
      'الإلمام بمراحل اختبار الاختراق الأربع',
      'التعرف على Kali Linux وأهم أدواته',
      'فهم أن الحماية تبدأ بفهم الهجوم'
    ],
    
    reviewQuestions: [
      'اشرح الفرق بين IIS و Apache من حيث نظام التشغيل والاستخدام',
      'لماذا يُعتبر HTTP بروتوكول عديم الحالة (Stateless)؟ وكيف تحل هذه المشكلة؟',
      'عدد مراحل اختبار الاختراق الأربع مع شرح موجز لكل مرحلة',
      'ما الفرق بين Vulnerability Scanner و Exploitation Tool؟',
      'اذكر 5 أدوات من Kali Linux مع وظيفة كل منها',
      'لماذا HTTPS لا يكفي لحماية التطبيق من الثغرات؟'
    ]
  },
  
  // =====================================================
  // الوحدات 2-7: هيكلية جاهزة (يمكنك ملء المحتوى لاحقاً)
  // =====================================================
  
  {
    id: 'unit-2',
    number: 2,
    title: 'استطلاع سيرفرات الويب',
    titleEn: 'Web Server Reconnaissance',
    description: 'تقنيات جمع المعلومات الاستباقية والتفاعلية عن الأهداف والأنظمة',
    estimatedTime: 120,
    objectives: ['التمييز بين الاستطلاع السلبي والنشط', 'استخدام مصادر الاستخبارات المفتوحة (OSINT)', 'تحليل سجلات DNS'],
    sections: [],
    quiz: [],
    summary: [],
    reviewQuestions: []
  },
  
  {
    id: 'unit-3',
    number: 3,
    title: 'البحث عن الثغرات والاستغلال',
    titleEn: 'Vulnerability Assessment & Exploitation',
    description: 'اكتشاف وتحليل الثغرات الأمنية واستخدام أطر العمل المتقدمة',
    estimatedTime: 150,
    objectives: ['إجراء مسح متقدم باستخدام Nmap', 'فهم عمل Metasploit Framework'],
    sections: [],
    quiz: [],
    summary: [],
    reviewQuestions: []
  },
  
  {
    id: 'unit-4',
    number: 4,
    title: 'استطلاع تطبيق الويب',
    titleEn: 'Web Application Reconnaissance',
    description: 'تحليل متعمق لتطبيقات الويب واكتشاف هيكلها ونقاط الدخول',
    estimatedTime: 120,
    objectives: ['استخدام بروكسي الاعتراض', 'تطبيق تقنيات Spidering'],
    sections: [],
    quiz: [],
    summary: [],
    reviewQuestions: []
  },
  
  {
    id: 'unit-5',
    number: 5,
    title: 'ثغرات الحقن (Injection)',
    titleEn: 'Injection Vulnerabilities',
    description: 'دراسة شاملة لهجمات الحقن SQL و Command Injection والدفاع ضدها',
    estimatedTime: 180,
    objectives: ['فهم آلية SQL Injection', 'تطبيق طرق الحماية'],
    sections: [],
    quiz: [],
    summary: [],
    reviewQuestions: []
  },
  
  {
    id: 'unit-6',
    number: 6,
    title: 'التحكم بالوصول والمصادقة',
    titleEn: 'Access Control & Authentication',
    description: 'استهداف أنظمة المصادقة والجلسات وطرق الحماية المتقدمة',
    estimatedTime: 120,
    objectives: ['فهم Access Control', 'شرح Session Management'],
    sections: [],
    quiz: [],
    summary: [],
    reviewQuestions: []
  },
  
  {
    id: 'unit-7',
    number: 7,
    title: 'هجمات جانب العميل',
    titleEn: 'Client-Side Attacks',
    description: 'هجمات XSS والهندسة الاجتماعية واستهداف المستخدمين النهائيين',
    estimatedTime: 120,
    objectives: ['فهم XSS بأنواعها', 'شرح CSRF و Clickjacking'],
    sections: [],
    quiz: [],
    summary: [],
    reviewQuestions: []
  }
];

// ✅ مختبر كالي لينكس العملي
export const practicalLab = {
  id: 'lab-kali',
  title: 'مختبر كالي لينكس العملي',
  description: 'بيئة آمنة لممارسة أدوات الاختبار',
  modules: [
    { title: 'تجهيز بيئة الاختبار', content: '✓ استخدم VirtualBox أو VMware\n✓ أنشئ شبكة معزولة (Host-only)\n✓ ثبّت DVWA أو WebGoat للتدريب' },
    { title: 'Nmap المتقدم', commands: [
      { cmd: 'nmap -sV -sC -p- 192.168.1.0/24', desc: 'مسح كامل مع اكتشاف الخدمات' },
      { cmd: 'nmap --script http-enum target.com', desc: 'اكتشاف تطبيقات الويب' }
    ]}
  ]
};

// ✅ دوال مساعدة
export const getUnitContent = (unitId) => {
  return units.find(u => u.id === unitId) || null;
};

export const getUnitsSummary = () => {
  return units.map(u => ({
    id: u.id,
    number: u.number,
    title: u.title,
    titleEn: u.titleEn,
    description: u.description,
    estimatedTime: u.estimatedTime,
    objectives: u.objectives
  }));
};

export default {
  courseOverview,
  units,
  practicalLab,
  getUnitContent,
  getUnitsSummary
};

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Suspense } from 'react';

// ✅ استيراد الأنماط الأساسية
import './index.css';
import './styles/main.css';

// ✅ استيراد الصفحات (بدون تكرار)
import Dashboard from './pages/Dashboard';
import UnitDetail from './pages/UnitDetail';
import Courses from './pages/Courses';

/**
 * مكون صفحة التحميل
 */
const LoadingPage = () => (
  <div className="loading-fullscreen" role="status" aria-live="polite">
    <motion.div
      className="loading-spinner"
      animate={{ rotate: 360 }}
      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      aria-hidden="true"
    >
      <div className="spinner-inner" />
    </motion.div>
    <p className="loading-text">جاري تحميل المنصة...</p>
    <small className="loading-credit">🔐 Engineered by Duha Twam</small>
  </div>
);

/**
 * مكون الصفحة الرئيسية مع الأنيميشن
 */
const PageTransition = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3, ease: "easeOut" }}
  >
    {children}
  </motion.div>
);

/**
 * المكون الرئيسي للتطبيق
 */
function App() {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.3, ease: "easeOut" }
    },
    exit: { 
      opacity: 0, 
      y: -20,
      transition: { duration: 0.2 }
    }
  };

  return (
    <Router>
      <div className="app" dir="rtl" lang="ar">
        {/* ✅ رابط تخطي المحتوى الرئيسي */}
        <a href="#main-content" className="skip-link">
          تخطي إلى المحتوى الرئيسي
        </a>

        {/* ✅ محتوى التطبيق مع الأنيميشن */}
        <AnimatePresence mode="wait">
          <Suspense fallback={<LoadingPage />}>
            <Routes>
              
              {/* 📚 الصفحة الرئيسية - اختيار المواد */}
              <Route 
                path="/" 
                element={
                  <PageTransition>
                    <Courses />
                  </PageTransition>
                } 
              />
              
              {/* 💻 Dashboard المادة النشطة */}
              <Route 
                path="/dashboard" 
                element={
                  <PageTransition>
                    <Dashboard />
                  </PageTransition>
                } 
              />
              
              {/* 📖 صفحة الوحدة الدراسية */}
              <Route 
                path="/unit/:unitId" 
                element={
                  <PageTransition>
                    <UnitDetail />
                  </PageTransition>
                } 
              />
              
              {/* 📡 صفحات المواد الأخرى (قريباً) */}
              <Route 
                path="/course/security-basics" 
                element={
                  <PageTransition>
                    <div className="coming-soon-page">
                      <h1>🔜 قريباً</h1>
                      <p>مادة أساسيات أمن المعلومات قيد التطوير</p>
                      <a href="/" className="back-link">العودة للصفحة الرئيسية</a>
                    </div>
                  </PageTransition>
                } 
              />
              
              <Route 
                path="/course/wireless-security" 
                element={
                  <PageTransition>
                    <div className="coming-soon-page">
                      <h1>🔜 قريباً</h1>
                      <p>مادة أمن الشبكات اللاسلكية قيد التطوير</p>
                      <a href="/" className="back-link">العودة للصفحة الرئيسية</a>
                    </div>
                  </PageTransition>
                } 
              />
              
              {/* ✅ إعادة التوجيه لأي مسار غير معروف */}
              <Route path="*" element={<Navigate to="/" replace />} />
              
            </Routes>
          </Suspense>
        </AnimatePresence>

        {/* ✅ منطقة للإشعارات الحية */}
        <div 
          id="live-region" 
          aria-live="polite" 
          aria-atomic="true" 
          className="sr-only"
        />
      </div>
    </Router>
  );
}

export default App;
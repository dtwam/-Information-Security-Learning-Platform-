/**
 * 📄 storage.js
 * وظائف التعامل مع LocalStorage بأمان
 * @module utils/storage
 */

// ✅ مفتاح التخزين
export const PROGRESS_KEY = 'cybersec_academy_progress_v1';

/**
 * تشفير بسيط للبيانات الحساسة (ملاحظة: في الإنتاج استخدم مكتبة متخصصة)
 * ⚠️ هذا للتوضيح فقط - لا يعتمد عليه لأمان حقيقي
 */
const simpleEncrypt = (data) => {
  try {
    // ✅ تحويل إلى JSON ثم Base64 (ليس تشفيرًا حقيقيًا)
    return btoa(encodeURIComponent(JSON.stringify(data)));
  } catch (e) {
    console.error('❌ فشل في "تشفير" البيانات:', e);
    return null;
  }
};

/**
 * فك التشفير البسيط
 */
const simpleDecrypt = (encrypted) => {
  try {
    return JSON.parse(decodeURIComponent(atob(encrypted)));
  } catch (e) {
    console.error('❌ فشل في فك "التشفير":', e);
    return null;
  }
};

/**
 * حفظ التقدم في LocalStorage
 * @param {Object} data - بيانات التقدم
 * @returns {boolean} نجاح العملية
 */
export const saveProgress = (data) => {
  try {
    // ✅ التحقق من صحة البيانات
    if (!data || typeof data !== 'object') {
      throw new Error('بيانات غير صالحة');
    }
    
    // ✅ إضافة طابع زمني
    const dataWithMeta = {
      ...data,
      savedAt: new Date().toISOString(),
      userAgent: navigator.userAgent?.slice(0, 100) // ✅ للتحقق من الجهاز
    };
    
    // ✅ الحفظ (بدون تشفير حقيقي لأغراض التعليم)
    // ⚠️ في الإنتاج: استخدم تشفيرًا حقيقيًا للبيانات الحساسة
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(dataWithMeta));
    
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ التقدم:', error);
    
    // ✅ معالجة مساحة التخزين الممتلئة
    if (error.name === 'QuotaExceededError') {
      console.warn('⚠️ مساحة LocalStorage ممتلئة - يتم تنظيف البيانات القديمة');
      // ✅ يمكن إضافة منطق تنظيف هنا
    }
    
    return false;
  }
};

/**
 * تحميل التقدم من LocalStorage
 * @returns {Object|null} بيانات التقدم أو null عند الفشل
 */
export const loadProgress = () => {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return null;
    
    const data = JSON.parse(raw);
    
    // ✅ التحقق من إصدار البيانات
    if (data.version !== '1.0') {
      console.warn('⚠️ إصدار بيانات مختلف - قد تحتاج للتحديث');
    }
    
    // ✅ التحقق من صلاحية الجلسة (اختياري)
    if (data.savedAt) {
      const saved = new Date(data.savedAt);
      const now = new Date();
      const daysDiff = (now - saved) / (1000 * 60 * 60 * 24);
      
      if (daysDiff > 30) {
        console.warn('⚠️ بيانات قديمة (>30 يوم) - يُنصح بالمزامنة');
      }
    }
    
    // ✅ إرجاع البيانات دون المعلومات التقنية
    const { savedAt, userAgent, ...cleanData } = data;
    return cleanData;
    
  } catch (error) {
    console.error('❌ فشل تحميل التقدم:', error);
    
    // ✅ في حالة تلف البيانات
    if (error instanceof SyntaxError) {
      console.warn('⚠️ بيانات LocalStorage تالفة - يتم إعادة التعيين');
      localStorage.removeItem(PROGRESS_KEY);
    }
    
    return null;
  }
};

/**
 * إعادة تعيين التقدم
 * @returns {boolean} نجاح العملية
 */
export const resetProgress = () => {
  try {
    localStorage.removeItem(PROGRESS_KEY);
    return true;
  } catch (error) {
    console.error('❌ فشل إعادة تعيين التقدم:', error);
    return false;
  }
};

/**
 * التحقق من دعم الميزات المطلوبة
 * @returns {Object} حالة الدعم
 */
export const checkStorageSupport = () => {
  const result = {
    localStorage: false,
    sessionStorage: false,
    quota: null
  };
  
  try {
    // ✅ اختبار localStorage
    const testKey = '__test__';
    localStorage.setItem(testKey, 'test');
    localStorage.removeItem(testKey);
    result.localStorage = true;
    
    // ✅ تقدير المساحة المتاحة
    let total = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        total += localStorage[key].length + key.length;
      }
    }
    result.quota = {
      used: total,
      estimated: 5 * 1024 * 1024, // ✅ 5MB تقريبًا
      percent: Math.round((total / (5 * 1024 * 1024)) * 100)
    };
    
  } catch (e) {
    console.warn('⚠️ localStorage غير متاح أو مقيد', e);
  }
  
  return result;
};

/**
 * دالة مساعدة للتحقق من المدخلات قبل الحفظ
 * @param {*} value - القيمة للتحقق
 * @param {Object} options - خيارات التحقق
 * @returns {boolean} هل القيمة صالحة؟
 */
export const validateForStorage = (value, options = {}) => {
  const {
    maxLength = 10000,
    allowObjects = true,
    sanitize = true
  } = options;
  
  // ✅ التحقق من النوع
  if (value === null || value === undefined) {
    return false;
  }
  
  // ✅ التحقق من الطول للنصوص
  if (typeof value === 'string' && value.length > maxLength) {
    console.warn(`⚠️ النص يتجاوز الطول المسموح: ${value.length} > ${maxLength}`);
    return false;
  }
  
  // ✅ التحقق من الكائنات
  if (typeof value === 'object' && !allowObjects) {
    console.warn('⚠️ الكائنات غير مسموحة في هذا السياق');
    return false;
  }
  
  // ✅ تنظيف بسيط (منع حقن الكود)
  if (sanitize && typeof value === 'string') {
    // ✅ إزالة وسوم script المحتملة
    if (/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi.test(value)) {
      console.warn('⚠️ تم اكتشاف كود محتمل - تم رفض القيمة');
      return false;
    }
  }
  
  return true;
};

// ✅ تصدير دوال مساعدة إضافية
export const storage = {
  save: saveProgress,
  load: loadProgress,
  reset: resetProgress,
  check: checkStorageSupport,
  validate: validateForStorage
};
const unitsWithProgress = React.useMemo(() => {
  return getUnitsSummary().map(unit => {
    // ...
  });
}, [progress.units]);
export default storage;
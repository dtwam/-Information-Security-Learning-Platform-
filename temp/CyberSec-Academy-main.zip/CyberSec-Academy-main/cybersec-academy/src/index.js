/**
 * 📄 index.js
 * نقطة دخول التطبيق
 * @module index
 */

import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

// ✅ التحقق من دعم الميزات الأساسية
const checkBrowserSupport = () => {
  const required = [
    'fetch' in window,
    'localStorage' in window,
    'Promise' in window,
    'Symbol' in window,
    'Object' in window && 'assign' in Object
  ];
  
  if (!required.every(Boolean)) {
    console.error('❌ المتصفح غير مدعوم. يرجى التحديث إلى Chrome 90+ أو Firefox 88+ أو Edge 90+');
    document.body.innerHTML = `
      <div style="padding: 2rem; text-align: center; background: #ef4444; color: white; font-family: Cairo, sans-serif;">
        <h2>⚠️ متصفح غير مدعوم</h2>
        <p>يرجى تحديث متصفحك أو استخدام:</p>
        <ul style="text-align: right; max-width: 400px; margin: 1rem auto;">
          <li>Google Chrome 90+</li>
          <li>Mozilla Firefox 88+</li>
          <li>Microsoft Edge 90+</li>
          <li>Safari 14+</li>
        </ul>
        <small>🔐 Engineered by Duha Twam</small>
      </div>
    `;
    return false;
  }
  return true;
};

// ✅ تهيئة التطبيق
const initApp = () => {
  // ✅ التحقق من دعم المتصفح
  if (!checkBrowserSupport()) {
    return;
  }
  
  // ✅ إعدادات الأداء
  if ('performance' in window && 'setResourceTimingBufferSize' in performance) {
    performance.setResourceTimingBufferSize(500);
  }
  
  // ✅ معالجة الأخطاء العامة
  window.addEventListener('error', (event) => {
    console.error('❌ خطأ عام في التطبيق:', event.error);
    // ✅ في الإنتاج: أرسل إلى خدمة تتبع الأخطاء
  });
  
  window.addEventListener('unhandledrejection', (event) => {
    console.error('❌ Promise مرفوض بدون معالجة:', event.reason);
  });
  
  // ✅ تسجيل معلومات الجلسة (لأغراض التعليم)
  console.group('🔐 منصة أمن المعلومات');
  console.log('✓ تم التحميل بنجاح');
  console.log('🎓 جامعة القدس المفتوحة');
  console.log('📚 برمجيات وتطبيقات أمن المعلومات');
  console.log('🔐 Engineered by Duha Twam');
  console.log('🌐 User Agent:', navigator.userAgent);
  console.log('📦 React Version:', React.version);
  console.groupEnd();
  
  // ✅ إنشاء جذر التطبيق
  const container = document.getElementById('root');
  if (!container) {
    console.error('❌ عنصر #root غير موجود في HTML');
    return;
  }
  
  const root = createRoot(container);
  
  // ✅ تشغيل التطبيق مع تحسينات StrictMode للتطوير
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
};

// ✅ بدء التطبيق عند جاهزية المستند
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

// ✅ تصدير لأغراض الاختبار (اختياري)
if (process.env.NODE_ENV === 'development') {
  window.__APP_INFO__ = {
    version: '1.0.0',
    build: new Date().toISOString(),
    features: {
      darkMode: true,
      rtl: true,
      offline: true,
      pwa: false
    }
  };
}

import { units, courseOverview } from '../data/courseContent';

/**
 * بحث بسيط في محتوى الوحدات
 */
function searchInContent(query, maxResults = 5) {
  const results = [];
  const q = query.toLowerCase().trim();
  
  const stopWords = new Set(['في', 'من', 'على', 'إلى', 'عن', 'هذا', 'هذه', 'ما', 'هو', 'هي', 'كيف', 'لماذا', 'the', 'a', 'an', 'is', 'are']);
  const keywords = q.split(/\s+/).filter(w => w.length > 2 && !stopWords.has(w));
  
  if (keywords.length === 0) return [];
  
  units.forEach(unit => {
    const unitText = `${unit.title} ${unit.titleEn} ${unit.description}`.toLowerCase();
    let score = keywords.filter(k => unitText.includes(k)).length;
    
    if (score > 0) {
      results.push({
        unitId: unit.id,
        title: unit.title,
        content: unit.description,
        score: score * 2,
        type: 'unit'
      });
    }
    
    unit.sections?.forEach(section => {
      const sectionText = `${section.title} ${section.content}`.toLowerCase();
      const sectionScore = keywords.filter(k => sectionText.includes(k)).length;
      
      if (sectionScore > 0) {
        results.push({
          unitId: unit.id,
          title: section.title,
          content: section.content?.substring(0, 300) + '...',
          score: sectionScore,
          type: section.type || 'concept'
        });
      }
    });
    
    unit.quiz?.forEach(quiz => {
      const quizText = `${quiz.question} ${quiz.explanation}`.toLowerCase();
      const quizScore = keywords.filter(k => quizText.includes(k)).length;
      
      if (quizScore > 0) {
        results.push({
          unitId: unit.id,
          title: 'سؤال اختبار',
          content: quiz.question,
          score: quizScore,
          type: 'quiz'
        });
      }
    });
  });
  
  return results
    .sort((a, b) => b.score - a.score)
    .slice(0, maxResults);
}

/**
 * توليد إجابة مبسطة بناءً على النتائج
 */
function generateSimpleAnswer(query, results) {
  if (!results || results.length === 0) {
    return {
      answer: `عذرًا، لم أجد معلومات عن "${query}" في محتوى المقرر الحالي.\n\n**اقتراحات:**\n• جرب استخدام كلمات أكثر تحديدًا\n• راجع الوحدات الدراسية مباشرة\n• اسأل عن مفهوم موجود في المنهج`,
      sources: [],
      suggestions: [
        'ما هو اختبار الاختراق؟',
        'اشرح بروتوكول HTTP',
        'ما هي ثغرات SQL Injection؟'
      ]
    };
  }
  
  const mainResult = results[0];
  let answer = `**${mainResult.title}**\n\n`;
  
  const content = mainResult.content
    .replace(/\*\*(.*?)\*\*/g, '**$1**')
    .replace(/^- /gm, '• ')
    .substring(0, 400);
  
  answer += content + (content.length >= 400 ? '...' : '') + '\n\n';
  
  if (results.length > 1) {
    answer += '**مواضيع ذات صلة:**\n';
    results.slice(1, 4).forEach(r => {
      answer += `• ${r.title}\n`;
    });
  }
  
  const suggestions = [];
  if (mainResult.type === 'concept') {
    suggestions.push('هل تريد مثالاً عمليًا على هذا المفهوم؟');
    suggestions.push('ما هي طرق الحماية من هذه الثغرة؟');
  }
  if (mainResult.type === 'unit') {
    suggestions.push('ما هي الأدوات المستخدمة في هذه الوحدة؟');
    suggestions.push('ما هي أهداف التعلم في هذه الوحدة؟'); // ✅ تم إصلاح هذا السطر
  }
  
  return {
    answer,
    sources: results.map(r => ({
      unitId: r.unitId,
      title: r.title,
      type: r.type
    })),
    suggestions: suggestions.slice(0, 3)
  };
}

/**
 * تحليل نوع السؤال
 */
function analyzeQuestionType(question) {
  const q = question.toLowerCase();
  
  if (q.includes('مثال') || q.includes('أمثلة')) return 'example';
  if (q.includes('اشرح') || q.includes('شرح') || q.includes('ببساطة')) return 'explanation';
  if (q.includes('اختبار') || q.includes('أسئلة') || q.includes('quiz')) return 'quiz';
  if (q.includes('فرق') || q.includes('مقارنة') || q.includes('بين')) return 'comparison';
  if (q.includes('ما هو') || q.includes('ما هي') || q.includes('تعريف')) return 'concept';
  
  return 'general';
}

/**
 * الدالة الرئيسية للتواصل مع المساعد
 */
export async function askAssistant(question, context = {}) {
  await new Promise(resolve => setTimeout(resolve, 500));
  
  try {
    const questionType = analyzeQuestionType(question);
    const results = searchInContent(question, 5);
    const response = generateSimpleAnswer(question, results);
    
    response.context = {
      questionType,
      relevantUnits: [...new Set(results.map(r => r.unitId))],
      timestamp: new Date().toISOString()
    };
    
    return {
      success: true,
      data: response
    };
  } catch (error) {
    console.error('AI Assistant Error:', error);
    return {
      success: false,
      error: 'حدث خطأ أثناء معالجة سؤالك. يرجى المحاولة مرة أخرى.'
    };
  }
}

export function getUnitContent(unitId) {
  return units.find(u => u.id === unitId) || null;
}

export function getAllUnits() {
  return units;
}

export default {
  askAssistant,
  getUnitContent,
  getAllUnits
};

import { units, courseOverview } from '../data/courseContent';

/**
 * فئة لتمثيل مستند قابل للبحث
 */
class SearchDocument {
  constructor(id, unitId, sectionId, title, content, type) {
    this.id = id;
    this.unitId = unitId;
    this.sectionId = sectionId;
    this.title = title;
    this.content = content;
    this.type = type; // 'concept', 'definition', 'example', 'warning'
    this.keywords = this.extractKeywords(content);
  }

  extractKeywords(text) {
    const commonWords = new Set(['في', 'من', 'على', 'إلى', 'عن', 'هذا', 'هذه', 'the', 'a', 'an', 'is', 'are']);
    const words = text.toLowerCase()
      .replace(/[^\w\s\u0600-\u06FF]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2 && !commonWords.has(word));
    return [...new Set(words)];
  }

  get searchableText() {
    return `${this.title} ${this.content}`.toLowerCase();
  }
}

/**
 * محرك RAG للبحث في محتوى المقرر
 */
class RAGEngine {
  constructor() {
    this.documents = [];
    this.indexed = false;
    this.index();
  }

  /**
   * فهرسة جميع محتوى الوحدات الدراسية
   */
  index() {
    this.documents = [];
    let docId = 0;

    // فهرسة نظرة عامة على المادة
    this.documents.push(new SearchDocument(
      `doc-${docId++}`,
      'overview',
      'overview',
      courseOverview.title,
      `${courseOverview.description} ${courseOverview.philosophy}`,
      'overview'
    ));

    // فهرسة كل وحدة وقسم
    units.forEach(unit => {
      // فهرسة معلومات الوحدة
      this.documents.push(new SearchDocument(
        `doc-${docId++}`,
        unit.id,
        'unit-info',
        unit.title,
        `${unit.title} ${unit.titleEn} ${unit.description} ${unit.objectives?.join(' ')}`,
        'unit-info'
      ));

      // فهرسة كل قسم في الوحدة
      unit.sections?.forEach((section, sectionIndex) => {
        let content = section.content || '';
        
        // إضافة محتوى infoBox إن وجد
        if (section.infoBox) {
          content += ` ${section.infoBox.content}`;
        }

        // إضافة محتوى tools إن وجد
        if (section.tools) {
          content += ` ${section.tools.map(t => `${t.name} ${t.desc}`).join(' ')}`;
        }

        // إضافة محتوى timeline إن وجد
        if (section.items) {
          content += ` ${section.items.map(item => `${item.title} ${item.desc}`).join(' ')}`;
        }

        // تحديد نوع المحتوى
        let type = 'concept';
        if (section.infoBox?.type === 'warning' || section.infoBox?.type === 'danger') {
          type = 'warning';
        } else if (section.type === 'code-example') {
          type = 'example';
        }

        this.documents.push(new SearchDocument(
          `doc-${docId++}`,
          unit.id,
          `section-${sectionIndex}`,
          section.title,
          content,
          type
        ));
      });

      // فهرسة أسئلة الاختبار
      unit.quiz?.forEach((quiz, quizIndex) => {
        this.documents.push(new SearchDocument(
          `doc-${docId++}`,
          unit.id,
          `quiz-${quizIndex}`,
          'سؤال اختبار',
          `${quiz.question} ${quiz.options?.join(' ')} ${quiz.explanation}`,
          'quiz'
        ));
      });

      // فهرسة الملخص
      if (unit.summary) {
        this.documents.push(new SearchDocument(
          `doc-${docId++}`,
          unit.id,
          'summary',
          'ملخص الوحدة',
          unit.summary.join(' '),
          'summary'
        ));
      }
    });

    this.indexed = true;
    console.log(`✅ RAG Engine: تم فهرسة ${this.documents.length} مستند`);
  }

  /**
   * البحث عن المستندات ذات الصلة بالسؤال
   * @param {string} query - سؤال المستخدم
   * @param {number} topK - عدد النتائج المطلوبة
   * @returns {Array} المستندات ذات الصلة
   */
  search(query, topK = 5) {
    if (!this.indexed) {
      this.index();
    }

    const queryKeywords = this.extractKeywords(query);
    
    // حساب درجة الصلة لكل مستند
    const scoredDocs = this.documents.map(doc => ({
      doc,
      score: this.calculateRelevance(doc, query, queryKeywords)
    }));

    // ترتيب حسب الدرجة وأخذ الأعلى
    return scoredDocs
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .filter(item => item.score > 0)
      .map(item => item.doc);
  }

  /**
   * حساب درجة الصلة بين المستند والسؤال
   */
  calculateRelevance(doc, query, queryKeywords) {
    let score = 0;

    // مطابقة الكلمات المفتاحية
    queryKeywords.forEach(keyword => {
      if (doc.keywords.includes(keyword)) {
        score += 3;
      }
      if (doc.searchableText.includes(keyword)) {
        score += 1;
      }
    });

    // مطابقة العنوان (أهم)
    if (doc.title.toLowerCase().includes(query.toLowerCase())) {
      score += 10;
    }

    // مطابقة نوع المحتوى
    if (query.includes('تحذير') && doc.type === 'warning') {
      score += 5;
    }
    if (query.includes('مثال') && doc.type === 'example') {
      score += 5;
    }
    if (query.includes('اختبار') && doc.type === 'quiz') {
      score += 5;
    }

    return score;
  }

  extractKeywords(text) {
    const commonWords = new Set(['في', 'من', 'على', 'إلى', 'عن', 'هذا', 'هذه', 'the', 'a', 'an', 'is', 'are', 'ما', 'هو', 'هي', 'كيف', 'لماذا']);
    const words = text.toLowerCase()
      .replace(/[^\w\s\u0600-\u06FF]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2 && !commonWords.has(word));
    return [...new Set(words)];
  }

  /**
   * الحصول على محتوى الوحدة كاملة
   */
  getUnitContent(unitId) {
    return units.find(u => u.id === unitId) || null;
  }

  /**
   * الحصول على جميع الوحدات
   */
  getAllUnits() {
    return units;
  }
}

// ✅ تصدير نسخة وحيدة من المحرك
export const ragEngine = new RAGEngine();
export default ragEngine;